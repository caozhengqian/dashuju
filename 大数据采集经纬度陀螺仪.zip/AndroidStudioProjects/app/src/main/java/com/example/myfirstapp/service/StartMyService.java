package com.example.myfirstapp.service;

import android.app.Service;
import android.content.Intent;
import android.hardware.SensorEventListener;
import android.os.IBinder;
import android.hardware.SensorManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.util.Log;
import android.provider.Settings;
import android.location.LocationManager;
import android.content.Context;
import android.location.Criteria;
import android.support.v4.app.ActivityCompat;
import android.Manifest;
import android.location.Location;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationQualityReport;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationListener;
import com.blankj.utilcode.util.ThreadUtils;
import com.google.gson.Gson;


import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class StartMyService extends Service implements SensorEventListener{

    public StartMyService() {
    }

    private SensorManager mSensorManager;
    private Sensor mLight;
    private SensorManager sensorManager = null;
    private Sensor gyroSensor = null;
    private String ANDROID_ID;
    private String getX;
    private String getY;
    private String getZ;
    private String getLongitude;//经度
    private String getLatitude;//纬度
    private String getTimeMill;//时间戳
    private String sendJsonData;//集合
    private LocationManager locationManager;
    private Double location;
    private static final int BAIDU_READ_PHONE_STATE = 100;//定位权限请求
    private static final int PRIVATE_CODE = 1315;//开启GPS权限
    private TextView tvResult;
    public Boolean isSend = true;
    private String actionDesc;
    private String actionCode;
    private String timeDescc="0000-00-00 00-00";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        actionDesc = intent.getStringExtra("key");
        actionCode = intent.getStringExtra("code");
        mSensorManager.registerListener(this, mLight, SensorManager.SENSOR_DELAY_NORMAL);
//        return START_NOT_STICKY;
        return  super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        Log.v("bb","onServiceCreate");
        super.onCreate();
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mLight = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        ANDROID_ID = Settings.System.getString(getContentResolver(), Settings.System.ANDROID_ID);

        //声明AMapLocationClient类对象
         AMapLocationClient mLocationClient = null;
//声明定位回调监听器
         AMapLocationListener mLocationListener = new AMapLocationListener(){
            @Override
            public void onLocationChanged(AMapLocation location) {
                if (null != location) {

                    StringBuffer sb = new StringBuffer();
                    //errCode等于0代表定位成功，其他的为定位失败，具体的可以参照官网定位错误码说明
                    if(location.getErrorCode() == 0){
                        sb.append("定位成功" + "\n");
                        sb.append("定位类型: " + location.getLocationType() + "\n");
                        sb.append("经    度    : " + location.getLongitude() + "\n");
                        getLongitude = String.valueOf(location.getLongitude());
                        sb.append("纬    度    : " + location.getLatitude() + "\n");
                        getLatitude = String.valueOf(location.getLatitude());
                        sb.append("精    度    : " + location.getAccuracy() + "米" + "\n");
                        sb.append("提供者    : " + location.getProvider() + "\n");

                        sb.append("速    度    : " + location.getSpeed() + "米/秒" + "\n");
                        sb.append("角    度    : " + location.getBearing() + "\n");
                        // 获取当前提供定位服务的卫星个数
                        sb.append("星    数    : " + location.getSatellites() + "\n");
                        sb.append("国    家    : " + location.getCountry() + "\n");
                        sb.append("省            : " + location.getProvince() + "\n");
                        sb.append("市            : " + location.getCity() + "\n");
                        sb.append("城市编码 : " + location.getCityCode() + "\n");
                        sb.append("区            : " + location.getDistrict() + "\n");
                        sb.append("区域 码   : " + location.getAdCode() + "\n");
                        sb.append("地    址    : " + location.getAddress() + "\n");
                        sb.append("兴趣点    : " + location.getPoiName() + "\n");
                        //定位完成的时间
                        sb.append("定位时间: " + Utils.formatUTC(location.getTime(), "yyyy-MM-dd HH:mm:ss") + "\n");



                    } else {
                        //定位失败
                        sb.append("定位失败" + "\n");
                        sb.append("错误码:" + location.getErrorCode() + "\n");
                        sb.append("错误信息:" + location.getErrorInfo() + "\n");
                        sb.append("错误描述:" + location.getLocationDetail() + "\n");
                    }
                    sb.append("***定位质量报告***").append("\n");
                    sb.append("* WIFI开关：").append(location.getLocationQualityReport().isWifiAble() ? "开启":"关闭").append("\n");
                    sb.append("* GPS状态：").append(getGPSStatusString(location.getLocationQualityReport().getGPSStatus())).append("\n");
                    sb.append("* GPS星数：").append(location.getLocationQualityReport().getGPSSatellites()).append("\n");
                    sb.append("* 网络类型：" + location.getLocationQualityReport().getNetworkType()).append("\n");
                    sb.append("* 网络耗时：" + location.getLocationQualityReport().getNetUseTime()).append("\n");
                    sb.append("****************").append("\n");
                    //定位之后的回调时间
                    sb.append("回调时间: " + Utils.formatUTC(System.currentTimeMillis(), "yyyy-MM-dd HH:mm:ss") + "\n");

                    //解析定位结果，
                    String result = sb.toString();
                    Log.v("gaodemap",result);
                    getTimeMill =  String.valueOf(System.currentTimeMillis());
                    SimpleDateFormat   formatter   =   new   SimpleDateFormat   ("yyyy-MM-dd HH:mm:ss");
//                    long  l = Long.valueOf(getTimeMill);
                    Date curDate =  new Date(System.currentTimeMillis());
                    timeDescc = String.valueOf(formatter.format(curDate));//单位秒
                    Map sendMap = new HashMap();
                    sendMap.put("id",ANDROID_ID);
                    sendMap.put("time",getTimeMill);
                    sendMap.put("timeDescc",timeDescc);
                    sendMap.put("longitude",getLongitude);
                    sendMap.put("latitude",getLatitude);
                    sendMap.put("x",getX);
                    sendMap.put("y",getY);
                    sendMap.put("z",getZ);
                    sendMap.put("actionCode",actionCode);
                    sendMap.put("actionDesc",actionDesc);
                    Gson gson=new Gson();
                    String sendGson = gson.toJson(sendMap);
//                    sendJsonData = "values"+sendGson;
                    sendJsonData = sendGson;
                    Log.v("gaodemap",sendGson);

                    ThreadUtils.getIoPool().execute(new Runnable() {
                        @Override
                        public void run(){
                            String result = "";
                            BufferedReader reader = null;
//                            String Json ="values"+ sendJsonData;
                            try {
                                if(isSend == true){


//                                URL url = new URL("http://bigdata-kafka-project.perf.pateo.com.cn/kafka/putMessage?values="+sendJsonData);
                                    URL url = new URL("http://bigdata-kafka-project.perf.pateo.com.cn/kafka/putMessage");
                                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                                    conn.setRequestMethod("POST");
                                    conn.setDoOutput(true);
                                    conn.setDoInput(true);
                                    conn.setUseCaches(false);
//                              conn.setRequestProperty("Connection", "Keep-Alive");
                                    conn.setRequestProperty("Charset", "UTF-8");
                                    // 设置文件类型:
                                    conn.setRequestProperty("Content-Type","application/json");
                                    // 设置接收类型否则返回415错误
                                    //conn.setRequestProperty("accept","*/*")此处为暴力方法设置接受所有类型，以此来防范返回415;
                                    conn.setRequestProperty("Accept","application/json");
                                    // 往服务器里面发送数据

//                                byte[] writebytes = Json.getBytes();
                                    // 设置文件长度
//                                conn.setRequestProperty("Content-Length", String.valueOf(writebytes.length));
                                    OutputStream outwritestream = conn.getOutputStream();
                                    outwritestream.write(sendJsonData.getBytes());
                                    outwritestream.flush();
                                    outwritestream.close();
                                    Log.v("gaodemap1","请求数据路");
                                    Log.v("gaodemap1", "doJsonPost: conn"+conn.getResponseCode());

                                    if (conn.getResponseCode() == 200) {
                                        Log.v("gaodemap1","通讯成功");
                                        reader = new BufferedReader(
                                                new InputStreamReader(conn.getInputStream()));
                                        result = reader.readLine();
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            } finally {
                                if (reader != null) {
                                    try {
                                        reader.close();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    });


//             Thread thread =       new Thread(){
//                        public void run(){
//                            String result = "";
//                            BufferedReader reader = null;
////                            String Json ="values"+ sendJsonData;
//                            try {
//                                if(isSend == true){
//
//
////                                URL url = new URL("http://bigdata-kafka-project.perf.pateo.com.cn/kafka/putMessage?values="+sendJsonData);
//                                URL url = new URL("http://bigdata-kafka-project.perf.pateo.com.cn/kafka/putMessage");
//                                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//                                conn.setRequestMethod("POST");
//                                conn.setDoOutput(true);
//                                conn.setDoInput(true);
//                                conn.setUseCaches(false);
////                              conn.setRequestProperty("Connection", "Keep-Alive");
//                               conn.setRequestProperty("Charset", "UTF-8");
//                                // 设置文件类型:
//                                 conn.setRequestProperty("Content-Type","application/json");
//                                // 设置接收类型否则返回415错误
//                                //conn.setRequestProperty("accept","*/*")此处为暴力方法设置接受所有类型，以此来防范返回415;
//                                 conn.setRequestProperty("Accept","application/json");
//                                // 往服务器里面发送数据
//
////                                byte[] writebytes = Json.getBytes();
//                                // 设置文件长度
////                                conn.setRequestProperty("Content-Length", String.valueOf(writebytes.length));
//                                OutputStream outwritestream = conn.getOutputStream();
//                                outwritestream.write(sendJsonData.getBytes());
//                                outwritestream.flush();
//                                outwritestream.close();
//                                Log.v("gaodemap1","请求数据路");
//                                Log.v("gaodemap1", "doJsonPost: conn"+conn.getResponseCode());
//
//                                if (conn.getResponseCode() == 200) {
//                                    Log.v("gaodemap1","通讯成功");
//                                    reader = new BufferedReader(
//                                            new InputStreamReader(conn.getInputStream()));
//                                    result = reader.readLine();
//                                }
//                                }
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            } finally {
//                                if (reader != null) {
//                                    try {
//                                        reader.close();
//                                    } catch (IOException e) {
//                                        e.printStackTrace();
//                                    }
//                                }
//                            }
//                        }
//                    };
//                      thread.start();



//                    Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                    tvResult.setText(result);
                } else {
                    tvResult.setText("定位失败，loc is null");
                    Log.v("gaodemap","shibai");
                }
            }
        };
//初始化定位
        mLocationClient = new AMapLocationClient(getApplicationContext());
//设置定位回调监听
        mLocationClient.setLocationListener(mLocationListener);
         AMapLocationClientOption mLocationOption = null;
//初始化AMapLocationClientOption对象
        mLocationOption = new AMapLocationClientOption();
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        mLocationOption.setOnceLocation(false);
        mLocationOption.setInterval(1000);
        //给定位客户端对象设置定位参数
        mLocationClient.setLocationOption(mLocationOption);
//启动定位
        mLocationClient.startLocation();

    }
    /**
     * 获取GPS状态的字符串
     * @param statusCode GPS状态码
     * @return
     */
    private String getGPSStatusString(int statusCode){
        String str = "";
        switch (statusCode){
            case AMapLocationQualityReport.GPS_STATUS_OK:
                str = "GPS状态正常";
                break;
            case AMapLocationQualityReport.GPS_STATUS_NOGPSPROVIDER:
                str = "手机中没有GPS Provider，无法进行GPS定位";
                break;
            case AMapLocationQualityReport.GPS_STATUS_OFF:
                str = "GPS关闭，建议开启GPS，提高定位质量";
                break;
            case AMapLocationQualityReport.GPS_STATUS_MODE_SAVING:
                str = "选择的定位模式中不包含GPS定位，建议选择包含GPS定位的模式，提高定位质量";
                break;
            case AMapLocationQualityReport.GPS_STATUS_NOGPSPERMISSION:
                str = "没有GPS定位权限，建议开启gps定位权限";
                break;
        }
        return str;
    }


    @Override
    public void onDestroy() {
        Log.v("bb","onServiceDestroy");
        super.onDestroy();
        isSend = false;
        mSensorManager.unregisterListener(this);
    }
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    @Override
    public void onSensorChanged(SensorEvent event) {

        Log.v("tuoluoyi","onServiceDestroy事件触发");
        Log.v("tuoluoyi",ANDROID_ID);
        Integer a  = (Integer) event.sensor.getType();
        Integer b  = (Integer) Sensor.TYPE_GYROSCOPE;
        Log.v("tuoluoyi",a.toString() );
        Log.v("tuoluoyi",b.toString() );
        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            Log.v("tuoluoyi","onServiceDestroy事件进入显示TYPE_GYROSCOPE");
            Log.v("tuoluoyi","事件：" + " x:" + event.values[0] + " y:" + event.values[1] + " z:" + event.values[2]);
            getX = String.valueOf(event.values[SensorManager.DATA_X]);
            getY = String.valueOf(event.values[SensorManager.DATA_Y]);
            getZ = String.valueOf(event.values[SensorManager.DATA_Z]);
        }else if(event.sensor.getType() == Sensor.TYPE_GYROSCOPE_UNCALIBRATED){
            Log.v("tuoluoyi","onServiceDestroy事件进入显示TYPE_GYROSCOPE_UNCALIBRATED");
            Log.v("tuoluoyi","事件：" + " x:" + event.values[0] + " y:" + event.values[1] + " z:" + event.values[2]);
        }

    }





}
