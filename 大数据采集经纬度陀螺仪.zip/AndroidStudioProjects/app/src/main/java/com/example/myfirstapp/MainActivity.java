package com.example.myfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.amap.api.location.AMapLocationClient;
import com.example.myfirstapp.service.StartMyService;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
    public Button startButton;
    public Button endButton;
    public Button staticButton;
    public Button goButton;
    public Button runButton;
    public Button bikeButton;
    public Button elebikeButton;
    public Button busButton;
    public Button metroButton;
    public Button goupButton;
    public Button godownButton;
    public Button dintiButton;
    public Set listButtons = new HashSet();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

//        Toast.makeText(getApplicationContext(),"===>start!",Toast.LENGTH_SHORT).show();
        System.out.print("开始onCreate");
        Log.v("aa","onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AMapLocationClient.setApiKey("538feb52b2b4d6fbb0247456f5375a13");
         startButton= findViewById(R.id.button6);
         endButton= findViewById(R.id.button7);
         staticButton= findViewById(R.id.button2);
         goButton= findViewById(R.id.button3);
         runButton= findViewById(R.id.button4);
         bikeButton= findViewById(R.id.button8);
         elebikeButton= findViewById(R.id.button9);
         busButton= findViewById(R.id.button11);
         metroButton= findViewById(R.id.button12);
         goupButton= findViewById(R.id.button13);
         godownButton= findViewById(R.id.button14);
         dintiButton= findViewById(R.id.button15);
        listButtons.add(staticButton);
        listButtons.add(goButton);
        listButtons.add(runButton);
        listButtons.add(bikeButton);
        listButtons.add(elebikeButton);
        listButtons.add(busButton);
        listButtons.add(metroButton);
        listButtons.add(goupButton);
        listButtons.add(godownButton);
        listButtons.add(dintiButton);
    }
    public void reColor(View view){
        for (Object value : listButtons) {
            Button val = (Button)value;
            val.setBackgroundColor(getResources().getColor(R.color.colordefault));
        }
        view.setBackgroundColor(getResources().getColor(R.color.colorAccent));
    }
    public void restartService(String str ,String code) {
        Intent  intentService = new Intent(this , StartMyService.class);
        stopService(intentService);
        intentService.putExtra("key",str);
        intentService.putExtra("code",code);
        startService(intentService);
    }
    public void staticButtonClick(View view) {
        reColor(view);
        restartService("staticButtonClick","1");
    }

    public void goButtonClick(View view) {
        reColor(view);
        restartService("goButtonClick","2");
    }

    public void runButtonClick(View view) {
        reColor(view);
        restartService("runButtonClick","3");
    }

    public void bikeButtonClick(View view) {
        reColor(view);
        restartService("bikeButtonClick","4");
    }

    public void elebikeButtonClick(View view) {
        reColor(view);
        restartService("elebikeButtonClick","5");
    }

    public void busButtonClick(View view) {
        reColor(view);
        restartService("busButtonClick","6");
    }

    public void metroButtonClick(View view) {
        reColor(view);
        restartService("metroButtonClick","7");
    }

    public void goupButtonClick(View view) {
        reColor(view);
        restartService("goupButtonClick","8");
    }

    public void dintiButtonClick(View view) {
        reColor(view);
        restartService("dintiButtonClick","9");
    }
    public void godownButtonClick(View view) {
        reColor(view);
        restartService("godownButtonClick","10");
    }

    public void startService(View view) {
        startButton.setEnabled(false);
        startButton.setText(R.string.button_started);
        endButton.setEnabled(true);
        endButton.setText(R.string.button_end);
        for (Object value : listButtons) {
            Button val = (Button)value;
            val.setEnabled(true);
        }
        Intent  intentService = new Intent(this , StartMyService.class);
        intentService.putExtra("key","unknow");
        intentService.putExtra("code","0");
        startService(intentService);
    }

    public void stopSevice(View view) {
        for (Object value : listButtons) {
            Button val = (Button)value;
            val.setBackgroundColor(getResources().getColor(R.color.colordefault));
        }
        startButton.setEnabled(true);
        startButton.setText(R.string.button_start);
        endButton.setEnabled(false);
        endButton.setText(R.string.button_ended);
        for (Object value : listButtons) {
            Button val = (Button)value;
            val.setEnabled(false);
        }
        Intent  intentService = new Intent(this , StartMyService.class);
        intentService.putExtra("key","stop");
        intentService.putExtra("code","-1");
        stopService(intentService);
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.v("aa","onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("aa","onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v("aa","onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v("aa","onStop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v("aa","onRestart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v("aa","onDestroy");
    }
}
