package com.example.myfirstapp.service;

import android.util.Log;

/**
 * Created by caozhengqian on 2018/12/5.
 */

public class SendTread extends Thread {
    public void run(){
        Log.v("gaodemap1","线程已启动");
    }
}
