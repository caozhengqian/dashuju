package com.pateo.appframework.common.adapter.listview;

/**
 * @author fangxin
 * @date 2018-8-23
 */

public interface IItemListener {
    void setListener(CommonViewHolder viewHolder);
}
