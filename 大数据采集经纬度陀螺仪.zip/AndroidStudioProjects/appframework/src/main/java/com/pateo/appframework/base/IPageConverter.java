package com.pateo.appframework.base;

import com.pateo.appframework.base.bean.BasePage;

/**
 * Created by huangxiaodong on 2018/8/14.
 */

public interface IPageConverter<T> {
    BasePage<T> convertToBasePage();
}
