package com.pateo.appframework.mqtt;

import android.os.Handler;
import android.os.Looper;
import android.util.Pair;

import com.pateo.appframework.base.bean.ErrorDetail;
import com.pateo.appframework.network.ErrorInjector;
import com.pateo.appframework.network.ICheckResponse;
import com.pateo.appframework.utils.AppLog;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;

/**
 * Created by huangxiaodong on 2018/8/24.
 */
public class SerialMqtt<T extends ICheckResponse> {
    private MqttAsyncClient mqttClient;
    private int timeout;
    private Handler handler;
    private Pair<String, MqttSubscribeCallback> topicPair;

    private Runnable timeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (null != topicPair) {
                String topic = topicPair.first;
                MqttSubscribeCallback<T> callback = topicPair.second;
                callback.onBusiFailed(topic, ErrorDetail.ERROR_TIMEOUT, ErrorInjector.getErrorMsg(ErrorDetail.ERROR_TIMEOUT));
            }
            topicPair = null;
        }
    };

    public SerialMqtt(MqttAsyncClient mqttClient, int timeout) {
        this.mqttClient = mqttClient;
        this.timeout = timeout;
        this.handler = new Handler(Looper.getMainLooper());
    }

    /***
     *
     * @param topic
     * @param qos
     * @param callback
     */
    public void subscribe(final String topic, final int qos, final MqttSubscribeCallback<T> callback) {
        final ErrorDetail errorBusy = ErrorInjector.getError(ErrorDetail.ERROR_BUSY, "");
        if (isBusy()) {
            callback.onBusiFailed(topic, errorBusy.errorCode, errorBusy.errorMsg);
            return;
        }

        //构造mqtt client
        if (null == mqttClient) {
            mqttClient = MqttSDK.buildClient();
            if (null == mqttClient) {
                callback.onBusiFailed(topic, errorBusy.errorCode, errorBusy.errorMsg);
            }
            return;
        }

        //连服务器
        if (!mqttClient.isConnected()) {
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            connOpts.setAutomaticReconnect(true);
            try {
                mqttClient.connect(connOpts, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        subscribeImpl(topic, qos, callback);
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        callback.onBusiFailed(topic, errorBusy.errorCode, errorBusy.errorMsg);
                    }
                });
            } catch (MqttException e) {
                callback.onBusiFailed(topic, errorBusy.errorCode, errorBusy.errorMsg);
                return;
            }
        } else {
            subscribeImpl(topic, qos, callback);
        }
    }

    public void unsubscribe(final String topic) {
        topicPair = null;
        handler.removeCallbacks(timeoutRunnable);
        if (null != mqttClient && mqttClient.isConnected()) {
            try {
                mqttClient.unsubscribe(topic);
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
    }

    public void release() {
        topicPair = null;
        handler.removeCallbacks(timeoutRunnable);
        if (null != mqttClient) {
            try {
                mqttClient.disconnect();
                mqttClient.close();
                mqttClient = null;
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean isBusy() {
        return (null != topicPair);
    }


    private void subscribeImpl(final String topic, int qos, final MqttSubscribeCallback callback) {
        try {
            mqttClient.subscribe(topic, qos, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    AppLog.d("mqtt subscribe " + topic + " success");
                    topicPair = new Pair<>(topic, callback);
                    handler.postDelayed(timeoutRunnable, timeout);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    AppLog.d("mqtt subscribe " + topic + " failure", exception.getMessage());
                }
            }, callback);
        } catch (MqttException e) {
            e.printStackTrace();
            callback.onBusiFailed(topic, ErrorDetail.ERROR_BUSY, ErrorInjector.getErrorMsg(ErrorDetail.ERROR_BUSY));
        }

    }
}
