package com.pateo.appframework.base.view;

import android.arch.lifecycle.MutableLiveData;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.databinding.Observable;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.pateo.appframework.R;
import com.pateo.appframework.base.viewmode.BaseViewModel;
import com.pateo.appframework.utils.AppActivityManager;
import com.pateo.appframework.utils.AppConfigure;
import com.pateo.appframework.utils.AppLog;
import com.pateo.appframework.utils.ToastUtils;
import com.pateo.appframework.widgets.BaseToolbar;
import com.pateo.appframework.widgets.CommonToolbar;
import com.pateo.appframework.widgets.ProgressDialog;
import com.pateo.appframework.widgets.PromptDialog;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * @author huangxiaodong
 * @date 2018/7/24
 */

public abstract class BaseActivity<A extends BaseActivity, B extends ViewDataBinding, VM extends BaseViewModel> extends AppCompatActivity {
    public static final String KEY_INTENT_EXTRA_BUNDLE = "DefArgs_bundle";
    public static final String KEY_INTENT_EXTRA_BUNDLE_ARGS = "intentArgs";


    protected String TAG = this.getClass().getSimpleName();
    protected A mActivity;
    protected B mBinding;
    protected VM mViewModel;
    private BaseToolbar toolbar;
    private IntentArgs intentArgs;
    private boolean check;
    protected HashMap<? extends BaseViewModel, String> vmMap = new HashMap<>();
    private Observable.OnPropertyChangedCallback mLoadingCallback;
    private Observable.OnPropertyChangedCallback mErrorCallback;
    private Observable.OnPropertyChangedCallback mTokenCallback;
    private MutableLiveData<Boolean> ldLoading = new MutableLiveData<>();

    private ProgressDialog progressDialog;
    private PromptDialog promptDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mActivity = (A) this;
        AppLog.d(TAG, "onCreate()", "TaskId=", mActivity.getTaskId());
        check = false;
        mBinding = DataBindingUtil.setContentView(this, setContentLayoutId());
        check = true;
        mViewModel = initViewModel();
        if (mViewModel == null) {
            mViewModel = (VM) new BaseViewModel(mActivity);
        }
        if (getIntent() != null && getIntent().getExtras() != null) {
            Bundle bundle = getIntent().getBundleExtra(KEY_INTENT_EXTRA_BUNDLE);
            if (bundle != null) {
                intentArgs = (IntentArgs) bundle.getSerializable(KEY_INTENT_EXTRA_BUNDLE_ARGS);
            }
        }
        checkCodeActivity();
        mLoadingCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                onShowProgress(mViewModel.dataLoading.get(), "");
            }
        };

        mErrorCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                BaseViewModel.VMErrorMsg data = mViewModel.error.get();
                onShowErrorMsg(data.errorCode, data.errorMsg);
            }
        };

        mTokenCallback = new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable observable, int i) {
                BaseViewModel.VMErrorMsg data = mViewModel.tokenExpired.get();
                onTokenExpired(data.errorCode, data.errorMsg);
            }
        };
        mViewModel.dataLoading.addOnPropertyChangedCallback(mLoadingCallback);
        mViewModel.error.addOnPropertyChangedCallback(mErrorCallback);
        mViewModel.tokenExpired.addOnPropertyChangedCallback(mTokenCallback);
        init(savedInstanceState);
        if (AppConfigure.IS_CHECK_WARN && toolbar == null) {
            for (View view : getAllChildViews(getWindow().getDecorView())) {
                if (view instanceof Toolbar) {
                    AppLog.e(TAG, "getToolbar()/setToolbar()");return;
                }
            }
        }
    }

    private List<View> getAllChildViews(View view) {
        List<View> allchildren = new ArrayList<View>(25);
        if (view instanceof ViewGroup) {
            ViewGroup vp = (ViewGroup) view;
            for (int i = 0; i < vp.getChildCount(); i++) {
                View viewchild = vp.getChildAt(i);
                allchildren.add(viewchild);
                allchildren.addAll(getAllChildViews(viewchild));
            }
        }
        return allchildren;
    }

    /**
     */
    protected abstract int setContentLayoutId();

    protected abstract VM initViewModel();

    protected abstract void init(Bundle savedInstanceState);

    public void setToolbar(@IdRes int xmlToolbarId) {
        this.toolbar = findViewById(xmlToolbarId);
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
        }
    }

    public BaseToolbar getToolbar() {
        if(toolbar == null){
            initBaseToolbar();
        }
        return toolbar;
    }

    private void initBaseToolbar(){
        FrameLayout contentView = getWindow().getDecorView().findViewById(android.R.id.content);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ViewGroup viewGroup =  (ViewGroup)contentView.getChildAt(0);
        if(!(viewGroup instanceof LinearLayout)){
            AppLog.e("activity 根布局不是 LinearLayout");
        }
        CommonToolbar toolbar = (CommonToolbar) mActivity.getLayoutInflater().inflate(R.layout.common_toolbar,null);
        toolbar.setTitle("");
        toolbar.setNavigationIcon(android.R.drawable.ic_delete);
        viewGroup.addView(toolbar,0,params);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        this.toolbar = toolbar;
    }

    @Override
    protected void onResume() {
        super.onResume();
        //将Activity实例添加到AppManager的堆栈
        AppActivityManager.getInstance().addActivity(this);
        MobclickAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //将Activity实例从AppManager的堆栈中移除
        AppActivityManager.getInstance().removeActivity(this);
        MobclickAgent.onPause(this);
    }

    public VM getmViewModel() {
        return mViewModel;
    }

    @Override
    protected void onDestroy() {
        if (null != mViewModel) {
            mViewModel.dataLoading.removeOnPropertyChangedCallback(mLoadingCallback);
            mViewModel.error.removeOnPropertyChangedCallback(mErrorCallback);
            mViewModel.tokenExpired.removeOnPropertyChangedCallback(mTokenCallback);
        }
        super.onDestroy();
        if (mBinding != null) {
            mBinding.unbind();
        }
    }

    /**
     * [页面跳转] * * @param clz
     */
    public void startActivity(Class<?> clz, IntentArgs.Builder builder) {
        Intent intent = new Intent();
        intent.setClass(this, clz);
        Bundle bundle = new Bundle();
        bundle.putSerializable("intentArgs", builder.build());
        intent.putExtra("DefArgs_bundle", bundle);
        startActivity(intent);
    }

    /**
     * [页面跳转] * * @param clz
     */
    public void startActivity(Class<?> clz) {
        Intent intent = new Intent();
        intent.setClass(this, clz);
        startActivity(intent);
    }

    /**
     * [携带数据的页面跳转] * * @param clz * @param bundle
     */
    public void startActivity(Class<?> clz, Bundle bundle) {
        Intent intent = new Intent();
        intent.setClass(this, clz);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }


    public IntentArgs getIntentArgs() {
        if (intentArgs == null) {
            AppLog.e("没有设置默认intent参数");
            intentArgs = new IntentArgs.Builder().build();
        }
        return intentArgs;
    }

    public IntentArgs.Builder buildArgs() {
        return new IntentArgs.Builder();
    }

    protected IntentArgs.Builder buildArguments() {
        return new IntentArgs.Builder();
    }

    @Override
    public void setContentView(int layoutResID) {
        if (AppConfigure.IS_CHECK_WARN && check) {
            AppLog.e(TAG, "必须使用DataBindingUtil.setContentView()方法!!");
            if (AppConfigure.IS_CHECK_CONSTRAINT) {
                throw new NullPointerException("必须使用DataBindingUtil.setContentView()方法!!");
            }
        }
        super.setContentView(layoutResID);
    }

    protected void onShowProgress(boolean show, String progressMsg) {
        if (null == progressDialog) {
            progressDialog = ProgressDialog.newInstance(progressMsg);
        }
        ldLoading.setValue(show);
        if (show) {
            AppCompatActivity activity = AppActivityManager.getInstance().currentActivity();
            if (null != activity) {
                progressDialog.setMessage(progressMsg)
                        .show(activity.getSupportFragmentManager(), null);
            }
        } else {
            progressDialog.dismissAllowingStateLoss();
        }
    }

    protected void onShowErrorMsg(String errorCode, String errorMsg) {
        AppLog.d(TAG, "onShowErrorMsg", errorCode, errorMsg);
//        if (null == promptDialog) {
//            promptDialog = PromptDialog.newInstance(errorMsg);
//        }
//        if (promptDialog.isAdded()) {
//            return;
//        }
//        promptDialog.setMessage(errorMsg);
        AppCompatActivity activity = AppActivityManager.getInstance().currentActivity();
        if (null != activity) {
//            promptDialog.show(activity.getSupportFragmentManager(), null);
            ToastUtils.showErrorMsgToast(activity, errorMsg);
        }
    }

    protected void onTokenExpired(String errorCode, String errorMsg) {

    }

    public MutableLiveData<Boolean> getLdLoading() {
        return ldLoading;
    }

    private void checkCodeActivity() {
        if (AppConfigure.IS_CHECK_WARN) {
            if (mBinding == null) {
                AppLog.e(TAG, "必须使用DataBindingUtil.setContentView()方法");
                if (AppConfigure.IS_CHECK_CONSTRAINT) {
                    throw new NullPointerException(TAG + "必须使用DataBindingUtil.setContentView()方法");
                }
            } else {
                String s = mBinding.getClass().getSimpleName().replace("Activity", "").replace("Binding", "");
                if (!TAG.replace("Activity", "").equals(s)) {
                    AppLog.e(TAG, "layout命名不规范");
                    if (AppConfigure.IS_CHECK_CONSTRAINT) {
                        throw new NullPointerException(TAG + "layout命名不规范");
                    }
                }
            }
        }
    }
}
