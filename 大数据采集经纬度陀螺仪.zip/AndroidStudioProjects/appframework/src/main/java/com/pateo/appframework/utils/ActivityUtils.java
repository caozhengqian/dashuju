/*
 * Copyright 2016, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pateo.appframework.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.pateo.appframework.R;

import java.lang.reflect.Field;
import java.util.List;

import static com.google.gson.internal.$Gson$Preconditions.checkNotNull;


/**
 * This provides methods to help Activities load their UI.
 */
public class ActivityUtils {
    /**
     * 添加Fragment到Activity，属于叠加型
     * @param fragmentManager
     * @param fragment
     * @param frameId
     */
    public static void addFragmentToActivity(@NonNull FragmentManager fragmentManager,
                                             @NonNull Fragment fragment, int frameId, String tag) {
        checkNotNull(fragmentManager);
        checkNotNull(fragment);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.add(frameId, fragment);
        List<Fragment> list = fragmentManager.getFragments();
        if (null != list && list.size() > 0) {
            boolean hasFragment = false;
            for(Fragment fg : list){
                if (fg instanceof DialogFragment){
                    continue;
                } else {
                    hasFragment = true;
                    transaction.hide(fg);
                    break;
                }
            }
            if (hasFragment) {
                transaction.addToBackStack(tag);
            }
        }
        transaction.commitAllowingStateLoss();
    }
    /**
     * 添加Fragment到Activity，属于替换型
     * @param fragmentManager
     * @param fragment
     * @param frameId
     */
    public static int replaceFragmentToActivity(@NonNull FragmentManager fragmentManager,
                                                @NonNull Fragment fragment, int frameId , String tag) {
        checkNotNull(fragmentManager);
        checkNotNull(fragment);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(frameId, fragment);
        List<Fragment> list = fragmentManager.getFragments();
        if (null != list && list.size() > 0) {
            boolean hasFragment = false;
            for(Fragment fg : list){
                if (fg instanceof DialogFragment){
                    continue;
                } else {
                    hasFragment = true;
                }
            }
            if (hasFragment) {
                transaction.addToBackStack(tag);
            }
        }
        return transaction.commitAllowingStateLoss();
    }
    public static int replaceFragmentToActivity(@NonNull FragmentManager fragmentManager,
                                                @NonNull Fragment fragment, int frameId) {
        return replaceFragmentToActivity(fragmentManager,fragment,frameId,null);
    }

    public static int replaceFragmentNoStack(@NonNull FragmentManager fragmentManager,
                                             @NonNull Fragment fragment, int frameId) {
        checkNotNull(fragmentManager);
        checkNotNull(fragment);
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(frameId, fragment);
        return transaction.commitAllowingStateLoss();
    }


    public static boolean isReleaseMode(Context context) {
        try {
            String packageName = context.getPackageName();
            Class clz = Class.forName(packageName + ".BuildConfig");
            Field field = clz.getDeclaredField("BUILD_TYPE");
            String buildType = (String) field.get(null);
            return buildType.equals("release");
        } catch (Exception e) {
            e.printStackTrace();
        }
        ApplicationInfo info = context.getApplicationInfo();
        return (info.flags & ApplicationInfo.FLAG_DEBUGGABLE) == 0;
    }

    /***
     * 判断应用是否在后台运行
     * @param context
     * @return
     */
    public static boolean isBackground(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.processName.equals(context.getPackageName())) {
                /* BACKGROUND=400 EMPTY=500 FOREGROUND=100 GONE=1000 PERCEPTIBLE=130 SERVICE=300 ISIBLE=200 */
                if (appProcess.importance != ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }

    public static void openInputKeyboard(Context context,View view){
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(view, 0);
    }

    public static void hideInputKeyboard(Context context,View view){
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

}
