package com.pateo.appframework.network;

import com.pateo.appframework.utils.AppConfigure;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Interceptor;

/**
 * Created by huangxiaodong on 2018/8/23.
 */

public class HttpConfigParams{
    private boolean logEnabled;
    private String debugUrl;
    private String releaseUrl;
    private String certificate;
    private int connectTimeout;
    private int readtTimeout;
    private int writeTimeout;
    private List<Interceptor> interceptorList = new ArrayList<>(10);

    public HttpConfigParams() {
        reset();
    }

    public void reset(){
        logEnabled = AppConfigure.isDebugMode();
        debugUrl = null;
        releaseUrl = null;
        certificate = null;
        connectTimeout = 10;
        readtTimeout = 5;
        writeTimeout = 5;
        interceptorList.clear();
        interceptorList.clear();

    }

    public HttpConfigParams addInterceptor(Interceptor interceptor){
        if (null != interceptor) {
            interceptorList.add(interceptor);
        }
        return this;
    }


    public HttpConfigParams setDebugUrl(String debugUrl) {
        this.debugUrl = debugUrl;
        return this;
    }

    public HttpConfigParams setReleaseUrl(String releaseUrl) {
        this.releaseUrl = releaseUrl;
        return this;
    }

    public HttpConfigParams setCertificate(String certificate) {
        this.certificate = certificate;
        return this;
    }

    public HttpConfigParams setReadtTimeout(int readtTimeout) {
        this.readtTimeout = readtTimeout;
        return this;
    }

    public HttpConfigParams setWriteTimeout(int writeTimeout) {
        this.writeTimeout = writeTimeout;
        return this;
    }

    public int getConnectTimeout() {
        return connectTimeout;
    }

    public HttpConfigParams setConnectTimeout(int timeout) {
        this.connectTimeout = timeout;
        return this;
    }

    public boolean isLogEnabled() {
        return logEnabled;
    }

    public HttpConfigParams setLogEnabled(boolean logEnabled) {
        this.logEnabled = logEnabled;
        return this;
    }

    public String getBaseUrl(){
        if (AppConfigure.isDebugMode()){
            return debugUrl;
        }
        return releaseUrl;
    }

    public String getCertificate() {
        return certificate;
    }

    public int getReadtTimeout() {
        return readtTimeout;
    }

    public int getWriteTimeout() {
        return writeTimeout;
    }

    public List<Interceptor> getInterceptorList() {
        return interceptorList;
    }
}