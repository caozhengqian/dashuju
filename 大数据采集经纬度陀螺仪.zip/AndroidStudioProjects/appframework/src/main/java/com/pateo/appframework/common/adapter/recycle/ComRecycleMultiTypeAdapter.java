package com.pateo.appframework.common.adapter.recycle;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

/**
 *
 * @author fangxin
 * @date 2018-8-23
 */
public abstract class ComRecycleMultiTypeAdapter<T> extends RecyclerView.Adapter<RecyclerViewHolder> {

    private List<T> data;
    private Context mContext;

    private IItemRecycleListener itemRcvListener;

    public ComRecycleMultiTypeAdapter(Context context, IItemRecycleListener iItemRecycleListener) {
        super();
        this.mContext = context;
        this.data = null;
        this.itemRcvListener = iItemRecycleListener;
    }

    /**
     * @param data 显示的数据
     */
    public ComRecycleMultiTypeAdapter(Context context, List<T> data, IItemRecycleListener iItemRecycleListener) {
        super();
        this.mContext = context;
        this.data = data;
        this.itemRcvListener = iItemRecycleListener;
    }


    @Override
    public RecyclerViewHolder onCreateViewHolder(final ViewGroup parent, int viewLayoutId) {
        RecyclerViewHolder viewHolder = RecyclerViewHolder.get(mContext, parent, viewLayoutId, itemRcvListener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        convert(holder, (T) data.get(position), getItemLayoutId((T) data.get(position)));
    }

    public abstract void convert(RecyclerViewHolder holder, T t, int layoutIndex);

    @Override
    public int getItemCount() {
        return data != null ? data.size() : 0;
    }

    /**
     * 修改，返回的是item的布局id则onCreateViewHolder的参数包含布局id
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        return getItemLayoutId(data.get(position));
    }

    /**
     * 获取要使用的布局文件id
     *
     * @param t 每个条目对应的数据对象
     * @return 使用的布局id
     */
    public abstract int getItemLayoutId(T t);

    public void setData(List<T> data) {
        this.data = data;
        notifyDataSetChanged();
    }
}
