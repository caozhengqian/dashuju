package com.pateo.appframework.utils;

import com.google.gson.Gson;

/**
 * Created by huangxiaodong on 2018/9/12.
 */

public class DeepCopy {
    private static Gson gson = new Gson();

    public static <T> T deepCopy(T o) {
        if (null == o) {
            return null;
        }
        return (T) gson.fromJson(gson.toJson(o), o.getClass());
    }
}
