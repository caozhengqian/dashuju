package com.pateo.appframework.widgets;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.content.res.AppCompatResources;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.pateo.appframework.R;


/**
 * Created by huangxiaodong on 2018/4/26.
 */

public class ProgressDialog extends CommonDialogFragment {
    private static final String PARAM_MSG = "param_msg";
    private String argMsg;
    private int count = 0;

    public static ProgressDialog newInstance(String msg) {
        ProgressDialog dialog = new ProgressDialog();
        Bundle b = new Bundle();
        b.putString(PARAM_MSG, msg);
        dialog.setArguments(b);
        return dialog;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (null != getArguments()) {
            argMsg = getArguments().getString(PARAM_MSG);
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_progress, null);
        dialog.setContentView(view);

        TextView tvMessage = view.findViewById(R.id.tv_message);
        tvMessage.setText(argMsg);
        ProgressBar progressBar = view.findViewById(R.id.pbar_progress);
        progressBar.setProgressDrawable(AppCompatResources.getDrawable(getActivity(), R.drawable.progress_bar_drawable));
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (null != dialog) {
            Window window = dialog.getWindow();
            WindowManager.LayoutParams lp = window.getAttributes();
            window.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
            window.setAttributes(lp);
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        count = 0;
    }


    @Override
    public void dismiss() {
        count--;
        if (count <= 0) {
            super.dismiss();
            count = 0;
        }
    }

    @Override
    public void dismissAllowingStateLoss() {
        count--;
        if (count <= 0) {
            super.dismissAllowingStateLoss();
            count = 0;
        }
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        if(count == 0) {
            super.show(manager, tag);
        }
        count++;
    }

    @Override
    public int show(FragmentTransaction transaction, String tag) {
        int id = 0;
        if (count == 0) {
            id = super.show(transaction, tag);
        }
        count++;
        return id;
    }

    @Override
    public void showNow(FragmentManager manager, String tag) {
        if (0 == count) {
            super.showNow(manager, tag);
        }
        count++;
    }

    public ProgressDialog setMessage(String message) {
        Dialog dialog = getDialog();
        if (null != dialog) {
            TextView tvMessage = dialog.findViewById(R.id.tv_message);
            if (null != tvMessage) {
                tvMessage.setText(message);
            }
        } else {
            Bundle bundle = new Bundle();
            bundle.putString(PARAM_MSG, message);
            setArguments(bundle);
        }
        return this;
    }
}
