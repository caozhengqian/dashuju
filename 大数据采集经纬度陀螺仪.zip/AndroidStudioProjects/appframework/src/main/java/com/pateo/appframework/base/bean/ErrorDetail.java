package com.pateo.appframework.base.bean;

/**
 * Created by huangxiaodong on 2018/8/8.
 */

public class ErrorDetail{
    public static final String ERROR_NO_NETWORK = "error_no_network";
    public static final String ERROR_TIMEOUT = "error_timeout";
    public static final String ERROR_BUSY = "error_busy";

    public static final int FLAG_DEFAULT = 1;
    public static final int FLAG_TIMEOUT = 2;
    public static final int FLAG_NO_NETWORK = 4;
    public static final int FLAG_REFRESH_TOKEN = 8;


    public String errorCode;
    public String errorMsg;
    public int flag;

    public ErrorDetail(String errorCode, String errorMsg,int flag) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
        this.flag = (flag == 0)?FLAG_DEFAULT:flag;
    }
}