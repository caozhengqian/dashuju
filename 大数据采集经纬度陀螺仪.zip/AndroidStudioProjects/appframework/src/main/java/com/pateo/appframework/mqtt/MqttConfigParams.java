package com.pateo.appframework.mqtt;

/**
 * Created by huangxiaodong on 2018/8/21.
 */

public class MqttConfigParams {
    public static final int QOS_AT_MOST_ONCE = 0; //不保证能收到一次
    public static final int QOS_AT_LEAST_ONCE = 1; //确保一次或者多次收到消息
    public static final int QOS_EXACTLY_ONCE = 2; // 确保只收到一次消息

    private boolean logEnabled;
    private String debugUrl;
    private String releaseUrl;
    private String clientId;
    private int qos;
    private int connectTimeout;

    public MqttConfigParams() {
        reset();
    }

    public void reset() {
        logEnabled = false;
        debugUrl = null;
        releaseUrl = null;
        connectTimeout = 60 * 1000;
        clientId = "";
        qos = QOS_EXACTLY_ONCE;
    }

    public boolean isLogEnabled() {
        return logEnabled;
    }

    public MqttConfigParams setLogEnabled(boolean logEnabled) {
        this.logEnabled = logEnabled;
        return this;
    }

    public String getDebugUrl() {
        return debugUrl;
    }

    public MqttConfigParams setDebugUrl(String debugUrl) {
        this.debugUrl = debugUrl;
        return this;
    }

    public String getReleaseUrl() {
        return releaseUrl;
    }

    public MqttConfigParams setReleaseUrl(String releaseUrl) {
        this.releaseUrl = releaseUrl;
        return this;
    }

    public String getClientId() {
        if (null == clientId){
            return "";
        }
        return clientId;
    }

    public MqttConfigParams setClientId(String clientId) {
        this.clientId = clientId;
        return this;
    }

    public int getQos() {
        return qos;
    }

    public MqttConfigParams setQos(int qos) {
        this.qos = qos;
        return this;
    }

    public int getConnectTimeout() {
        return connectTimeout;
    }

    public MqttConfigParams setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
        return this;
    }
}
