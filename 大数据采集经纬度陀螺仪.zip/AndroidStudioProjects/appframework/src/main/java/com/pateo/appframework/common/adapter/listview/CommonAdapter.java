package com.pateo.appframework.common.adapter.listview;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.List;

/**
 * ListView通用适配器
 *
 * @author fangxin
 * @date 2018-8-23
 */
public abstract class CommonAdapter<T> extends BaseAdapter {
    private Context mContext;
    private List<T> data;
    private final int mItemLayoutId;
    private IItemListener itemListener;

    public CommonAdapter(Context context, List<T> data, int itemLayoutId, IItemListener itemListener) {
        this.mContext = context;
        this.data = data;
        this.mItemLayoutId = itemLayoutId;
        this.itemListener = itemListener;
    }

    @Override
    public int getCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public T getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final CommonViewHolder viewHolder = getViewHolder(position, convertView,
                parent);
        convert(viewHolder, getItem(position));
        return viewHolder.getConvertView();
    }

    /**
     * 需要自己实现的方法，这个方法，用来处理条目的显示效果
     *
     * @param holder 里面有布局文件的控件
     * @param t      每个条目对应的数据对象
     */
    public abstract void convert(CommonViewHolder holder, T t);

    private CommonViewHolder getViewHolder(int position, View convertView,
                                           ViewGroup parent) {
        return CommonViewHolder.get(mContext, convertView, parent, mItemLayoutId,
                position, itemListener);
    }

    public void setData(List<T> data) {
        this.data = data;
        notifyDataSetChanged();
    }
}