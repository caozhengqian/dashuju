package com.pateo.appframework.widgets;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.pateo.appframework.R;

/**
 * Created by huangxiaodong on 2018/4/26.
 */

public class ConfirmDialog extends CommonDialogFragment {
    private static final String PARAM_MSG = "param_msg";
    private static final String PARAM_YES = "param_yes";
    private static final String PARAM_NO = "param_no";
    private static final String PARAM_LAYOUT = "param_layout";
    private String argMsg;
    private String argYes;
    private String argNo;
    private int argLayoutId = 0;

    public static ConfirmDialog newConfirmDialog(int layoutId, String msg, String noStr, String yesStr) {
        ConfirmDialog dialog = new ConfirmDialog();
        Bundle b = new Bundle();
        b.putString(PARAM_MSG, msg);
        b.putString(PARAM_YES, yesStr);
        b.putString(PARAM_NO, noStr);
        b.putInt(PARAM_LAYOUT, layoutId);
        dialog.setArguments(b);
        return dialog;
    }

    public static ConfirmDialog newConfirmDialog(String msg, String noStr, String yesStr) {
        ConfirmDialog dialog = new ConfirmDialog();
        Bundle b = new Bundle();
        b.putString(PARAM_MSG, msg);
        b.putString(PARAM_YES, yesStr);
        b.putString(PARAM_NO, noStr);
        b.putInt(PARAM_LAYOUT, 0);
        dialog.setArguments(b);
        return dialog;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (null != getArguments()) {
            argMsg = getArguments().getString(PARAM_MSG);
            argNo = getArguments().getString(PARAM_NO);
            argYes = getArguments().getString(PARAM_YES);
            argLayoutId = getArguments().getInt(PARAM_LAYOUT);
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        if (argLayoutId == 0) {
            builder.setMessage(argMsg);
            if (!TextUtils.isEmpty(argYes)) {
                builder.setPositiveButton(argYes, clickListener);
            }
            return builder.create();
        }

        View view = LayoutInflater.from(getActivity()).inflate(argLayoutId, null);
        builder.setView(view);

        TextView tvMessage = view.findViewById(R.id.tv_message);
        if (!TextUtils.isEmpty(argMsg)) {
            tvMessage.setText(argMsg);
        }

        Button btnYes = view.findViewById(R.id.btn_yes);
        if (!TextUtils.isEmpty(argYes)) {
            btnYes.setText(argYes);
        }
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissAllowingStateLoss();
                if (null != clickListener) {
                    clickListener.onClick(getDialog(), DialogInterface.BUTTON_POSITIVE);
                }
            }
        });

        Button btnNo = view.findViewById(R.id.btn_no);
        if (!TextUtils.isEmpty(argNo)) {
            btnNo.setText(argNo);
        }
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissAllowingStateLoss();
                if (null != clickListener) {
                    clickListener.onClick(getDialog(), DialogInterface.BUTTON_NEGATIVE);
                }
            }
        });
        return builder.create();
    }

//    public ConfirmDialog setMessage(String message) {
//        argMsg = message;
//        Dialog dialog = getDialog();
//        if (null != dialog) {
//            TextView tvMessage = dialog.findViewById(R.id.tv_message);
//            if (null != tvMessage) {
//                tvMessage.setText(message);
//            }
//        }
//        return this;
//    }
//
//    public ConfirmDialog setPositiveButton(String str) {
//        argYes = str;
//        Dialog dialog = getDialog();
//        if (null != dialog) {
//            Button btnYes = dialog.findViewById(R.id.btn_yes);
//            if (null != btnYes && !TextUtils.isEmpty(argYes)) {
//                btnYes.setText(argYes);
//            }
//        }
//        return this;
//    }
//
//    public ConfirmDialog setNegativeButton(String str) {
//        argNo = str;
//        Dialog dialog = getDialog();
//        if (null != dialog) {
//            Button btnNo = dialog.findViewById(R.id.btn_no);
//            if (null != btnNo && !TextUtils.isEmpty(argNo)) {
//                btnNo.setText(argNo);
//            }
//        }
//        return this;
//    }
}
