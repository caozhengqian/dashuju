package com.pateo.appframework.network.monitor;

/**
 * @author huangxiaodong
 * @date 2018/7/20
 */
public interface NetworkMonitor {
    boolean isConnected();
}
