package com.pateo.appframework.base.model;

import android.databinding.Observable;

/**
 * Created by huangxiaodong on 2018/8/10.
 */

public interface ILocationModel {
    public void register(Observable.OnPropertyChangedCallback callback);

    public void unregister(Observable.OnPropertyChangedCallback callback);

    public void startLocation();
}
