package com.pateo.appframework.base.model;

/**
 * @author huangxiaodong
 * @date 2018/7/20
 */

public interface IModelCallback<T> {
    void onSuccess(T t);

    void onFailure(String errorCode, String errorMsg);

    void onTokenExpired(String errorCode, String errorMsg);
}
