package com.pateo.appframework.mqtt;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;
import com.pateo.appframework.base.bean.ErrorDetail;
import com.pateo.appframework.network.ErrorInjector;
import com.pateo.appframework.network.ICheckResponse;
import com.pateo.appframework.utils.AppLog;

import org.eclipse.paho.client.mqttv3.IMqttMessageListener;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * Created by huangxiaodong on 2018/8/21.
 */

public abstract class MqttSubscribeCallback<T extends ICheckResponse> implements IMqttMessageListener{
    private static final Gson GSON = new Gson();
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void messageArrived(String topic, MqttMessage mqttMessage) {
        try {
            String message = mqttMessage.toString();
            AppLog.d(this.getClass().getSimpleName(),message);

            MqttMessageResponse response = GSON.fromJson(message, MqttMessageResponse.class);
            Type type = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
            T body = GSON.fromJson(response.getMessage().getPushBody(), type);

            if (body.isBusinessSuccess()) {
                handler.post(new BusiSuccessRunnable(topic, body));
            } else {
                handler.post(new BusiFailedRunnable(topic, body.getBusinessCode(), body.getBusinessMessage()));
            }
        } catch (Exception e) {
            e.printStackTrace();
            handler.post(new BusiFailedRunnable(topic, ErrorDetail.ERROR_BUSY, ErrorInjector.getErrorMsg(ErrorDetail.ERROR_BUSY)));
        }
    }

    /**
     * mqtt通讯完成，失败调用
     *
     * @param topic
     * @param errorCode
     * @param errorMsg
     */
    protected abstract void onBusiFailed(String topic, String errorCode, String errorMsg);

    /**
     * mqtt通讯完成，业务成功回调
     *
     * @param topic 订阅主题
     * @param body  可能为 null，子类实现中需根据需要进行非空判断
     */
    protected abstract void onBusiSuccess(String topic, T body);


    private class BusiFailedRunnable implements Runnable{
        private String topic;
        private String errorCode;
        private String errorMsg;

        public BusiFailedRunnable(String topic, String errorCode, String errorMsg) {
            this.topic = topic;
            this.errorCode = errorCode;
            this.errorMsg = errorMsg;
        }

        @Override
        public void run() {
            onBusiFailed(topic,errorCode,errorMsg);
        }
    }

    private class BusiSuccessRunnable implements Runnable{
        private String topic;
        private T body;

        public BusiSuccessRunnable(String topic, T body) {
            this.topic = topic;
            this.body = body;
        }

        @Override
        public void run() {
            onBusiSuccess(topic,body);
        }
    }
}
