package com.pateo.appframework.common.adapter.recyclebind;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

/**
 *
 * @author fangxin
 * @date 2018-8-23
 */
public abstract class ComRecycleMultiTypeBindAdapter<T> extends RecyclerView.Adapter<RecyclerViewBindHolder> {

    private List<T> data;
    private Context mContext;

    private IItemRecycleBindListener itemRcvBindListener;

    public ComRecycleMultiTypeBindAdapter(Context context, IItemRecycleBindListener itemRcvBindListener) {
        super();
        this.mContext = context;
        this.data = null;
        this.itemRcvBindListener = itemRcvBindListener;
    }

    /**
     * @param context
     * @param data    显示的数据
     */
    public ComRecycleMultiTypeBindAdapter(Context context, List<T> data, @NonNull IItemRecycleBindListener itemRcvBindListener) {
        super();
        this.mContext = context;
        this.data = data;
        this.itemRcvBindListener = itemRcvBindListener;
    }


    @Override
    public RecyclerViewBindHolder onCreateViewHolder(final ViewGroup parent, int viewLayoutId) {
        RecyclerViewBindHolder viewHolder = RecyclerViewBindHolder.get(mContext, parent, viewLayoutId, itemRcvBindListener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewBindHolder holder, int position) {
        convert(holder, (T) data.get(position), getItemLayoutId((T) data.get(position)));
    }

    public abstract void convert(RecyclerViewBindHolder holder, T t, int layoutIndex);

    @Override
    public int getItemCount() {
        return data != null ? data.size() : 0;
    }

    /**
     * 修改，返回的是item的布局id则onCreateViewHolder的参数包含布局id
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        return getItemLayoutId(data.get(position));
    }

    /**
     * 获取要使用的布局文件id
     *
     * @param t 每个条目对应的数据对象
     */
    public abstract int getItemLayoutId(T t);

    public void setData(List<T> data) {
        this.data = data;
        notifyDataSetChanged();
    }
}
