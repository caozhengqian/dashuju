package com.pateo.appframework.widgets;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.pateo.appframework.R;


/**
 * Created by huangxiaodong on 2018/4/26.
 */

public class PromptDialog extends CommonDialogFragment {
    private static final String PARAM_MSG = "param_msg";
    private String argMsg;

    public static PromptDialog newInstance(String msg) {
        PromptDialog dialog = new PromptDialog();
        Bundle b = new Bundle();
        b.putString(PARAM_MSG, msg);
        dialog.setArguments(b);
        return dialog;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (null != getArguments()) {
            argMsg = getArguments().getString(PARAM_MSG);
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.dialog_prompt, null);
        builder.setView(view);

        TextView tvMessage = view.findViewById(R.id.tv_message);
        tvMessage.setText(argMsg);
        Button btnSure = view.findViewById(R.id.btn_ok);
        btnSure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissAllowingStateLoss();
            }
        });
        return builder.create();
    }

    public PromptDialog setMessage(String message) {
        Dialog dialog = getDialog();
        if (null != dialog) {
            TextView tvMessage = dialog.findViewById(R.id.tv_message);
            if (null != tvMessage) {
                tvMessage.setText(message);
            }
        } else {
            Bundle bundle = new Bundle();
            bundle.putString(PARAM_MSG, message);
            setArguments(bundle);
        }
        return this;
    }
}
