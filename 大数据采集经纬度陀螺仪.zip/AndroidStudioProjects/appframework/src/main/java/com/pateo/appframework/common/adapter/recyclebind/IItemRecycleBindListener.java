package com.pateo.appframework.common.adapter.recyclebind;


/**
 *
 * @author fangxin
 * @date 2018-8-23
 */
public interface IItemRecycleBindListener {
    void setListener(RecyclerViewBindHolder holder);
}
