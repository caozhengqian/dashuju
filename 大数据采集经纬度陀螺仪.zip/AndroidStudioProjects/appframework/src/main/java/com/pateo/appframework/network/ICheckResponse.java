package com.pateo.appframework.network;

/**
 * ICheckResponse
 *
 * @author fangxin
 * @date 2018-8-7
 */

public interface ICheckResponse {
    /**
     *
     * @return
     */
    boolean isBusinessSuccess();
    /**
     *
     * @return
     */
    String getBusinessCode();

    /**
     *
     * @return
     */
    String getBusinessMessage();
}
