package com.pateo.appframework.widgets;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.util.AttributeSet;

/**
 * CustomToolbar
 *
 * @author fangxin
 * @date 2018/10/23
 */

public class CommonToolbar extends BaseToolbar {
    public CommonToolbar(Context context) {
        super(context);
    }

    public CommonToolbar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CommonToolbar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public Drawable defNavigationIcon() {
        return getResources().getDrawable(android.R.drawable.ic_dialog_alert,null);
    }
}
