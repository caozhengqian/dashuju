package com.pateo.appframework.base.view;

/**
 * OnItemListener.java
 * Created at 2018/9/9
 * Created by wangxinwen
 * Copyright(C)2012,All rights reserved.
 */

public interface OnItemListener<T> {

   void onItemClick(T t);

   void onItemRemove(T t);

}
