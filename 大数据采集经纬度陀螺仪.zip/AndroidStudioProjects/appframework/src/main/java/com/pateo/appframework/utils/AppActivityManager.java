package com.pateo.appframework.utils;


import android.support.v7.app.AppCompatActivity;

import java.util.NoSuchElementException;
import java.util.Stack;

/**
 * Created by huangxiaodong on 2018/6/14.
 */

public class AppActivityManager {
    private static Stack<AppCompatActivity> activityStack;
    private static final AppActivityManager ourInstance = new AppActivityManager();

    public static AppActivityManager getInstance() {
        return ourInstance;
    }

    private AppActivityManager() {
    }

    /**
     * 添加Activity到堆栈
     */
    public void addActivity(AppCompatActivity activity) {
        if (activityStack == null) {
            activityStack = new Stack<AppCompatActivity>();
        }
        activityStack.add(activity);
    }

    public void removeActivity(AppCompatActivity activity){
        if (null == activityStack){
            return;
        }
        if (null != activity) {
            activityStack.remove(activity);
        }
    }

    /**
     * 获取当前Activity（堆栈中最后一个压入的）
     */
    public AppCompatActivity currentActivity() {
        AppCompatActivity activity;
        try {
            activity = activityStack.lastElement();
        } catch (NoSuchElementException e) {
            activity = null;
        }
        return activity;
    }

    /**
     * 结束当前Activity（堆栈中最后一个压入的）
     */
    public void finishActivity() {
        AppCompatActivity activity = activityStack.lastElement();
        if (activity != null) {
            activity.finish();
            activity = null;
        }
    }

    /**
     * 结束指定的Activity
     */
    public void finishActivity(AppCompatActivity activity) {
        if (activity != null) {
            activityStack.remove(activity);
            activity.finish();
            activity = null;
        }
    }

    /**
     * 结束指定类名的Activity
     */
    public void finishActivity(Class<?> cls) {
        for (AppCompatActivity activity : activityStack) {
            if (activity.getClass().equals(cls)) {
                finishActivity(activity);
            }
        }
    }

    /**
     * 结束所有Activity
     */
    public void finishAllActivity() {
        for (int i = 0, size = activityStack.size(); i < size; i++) {
            if (null != activityStack.get(i)) {
                activityStack.get(i).finish();
            }
        }
        activityStack.clear();
    }
}
