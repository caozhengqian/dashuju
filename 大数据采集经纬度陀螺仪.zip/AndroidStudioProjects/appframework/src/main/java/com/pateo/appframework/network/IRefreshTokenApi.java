package com.pateo.appframework.network;

import com.pateo.appframework.base.model.IModelCallback;

/**
 * Created by huangxiaodong on 2018/8/8.
 */

public interface IRefreshTokenApi<T> {
    /**
     * 刷新accessToken信息
     * @param callback
     */
    void refreshToken(IModelCallback<T> callback);
}
