package com.pateo.appframework.base.bean;

import java.util.List;

/**
 * Created by huangxiaodong on 2018/4/4.
 */

public class BasePage<V> {
    public static final int FIRST_PAGE_INDEX = 1;
    public static final int DEFAULT_PAGE_SIZE = 20;

    private V pageData;
    private int pageIndex;
    private int pageSize;
    private int totalCount;
    private int totalPage;

    public BasePage() {
        this.pageIndex = FIRST_PAGE_INDEX;
        this.pageSize = DEFAULT_PAGE_SIZE;
    }

    public BasePage(int pageIndex, int pageSize) {
        this.pageIndex = pageIndex;
        this.pageSize = pageSize;
    }

    public void reset(){
        this.pageIndex = FIRST_PAGE_INDEX;
        this.pageSize = DEFAULT_PAGE_SIZE;
        this.totalPage = 0;
        this.totalCount = 0;
        if (null != pageData && pageData instanceof List){
            List list = (List)pageData;
            list.clear();
        }
    }

    public V getPageData() {
        return pageData;
    }

    public void setPageData(V pageData) {
        this.pageData = pageData;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }
}
