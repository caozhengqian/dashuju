package com.pateo.appframework.network.interceptor;

import com.pateo.appframework.network.monitor.NetworkMonitor;
import com.pateo.appframework.network.monitor.NoNetworkException;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Response;

/**
 * Created by huangxiaodong on 2018/8/8.
 */

public class NetworkMonitorInterceptor implements Interceptor {
    NetworkMonitor networkMonitor;

    public NetworkMonitorInterceptor(NetworkMonitor networkMonitor) {
        this.networkMonitor = networkMonitor;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        boolean connected = networkMonitor.isConnected();
        if (connected) {
            return chain.proceed(chain.request());
        } else {
            throw new NoNetworkException();
        }
    }
}