package com.pateo.appframework.base.view;

import android.os.Parcelable;

import java.io.Serializable;
import java.lang.reflect.Type;

/**
 * IntentArgs
 *
 * activity页面跳转携带的简单参数
 * @author fangxin
 * @date 2018-8-24
 */

public class IntentArgs implements Serializable {
    private boolean aBoolean;
    private int anInt;
    private String str;
    private String jsonStr;
    private Type type;
    private Class aClass;
    private Parcelable parcelable;
    private Serializable serializable;

    private IntentArgs(Builder builder) {
        setaBoolean(builder.aBoolean);
        setAnInt(builder.anInt);
        setStr(builder.str);
        setJsonStr(builder.jsonStr);
        setType(builder.type);
        aClass = builder.aClass;
        setParcelable(builder.parcelable);
        setSerializable(builder.serializable);
    }

    public boolean isaBoolean() {
        return aBoolean;
    }

    public void setaBoolean(boolean aBoolean) {
        this.aBoolean = aBoolean;
    }

    public int getAnInt() {
        return anInt;
    }

    public void setAnInt(int anInt) {
        this.anInt = anInt;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public String getJsonStr() {
        return jsonStr;
    }

    public void setJsonStr(String jsonStr) {
        this.jsonStr = jsonStr;
    }

    public Type getType() {
        return type;
    }

    public Class getaClass() {
        return aClass;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Parcelable getParcelable() {
        return parcelable;
    }

    public void setParcelable(Parcelable parcelable) {
        this.parcelable = parcelable;
    }

    public Serializable getSerializable() {
        return serializable;
    }

    public void setSerializable(Serializable serializable) {
        this.serializable = serializable;
    }

    public static final class Builder {
        private boolean aBoolean;
        private int anInt;
        private String str;
        private String jsonStr;
        private Type type;
        private Class aClass;
        private Parcelable parcelable;
        private Serializable serializable;

        public Builder() {
        }

        public Builder aBoolean(boolean val) {
            aBoolean = val;
            return this;
        }

        public Builder anInt(int val) {
            anInt = val;
            return this;
        }

        public Builder str(String val) {
            str = val;
            return this;
        }

        public Builder jsonStr(String val) {
            jsonStr = val;
            return this;
        }

        public Builder type(Type val) {
            type = val;
            return this;
        }

        public Builder aClass(Class val) {
            aClass = val;
            return this;
        }

        public Builder parcelable(Parcelable val) {
            parcelable = val;
            return this;
        }

        public Builder serializable(Serializable val) {
            serializable = val;
            return this;
        }

        public IntentArgs build() {
            return new IntentArgs(this);
        }
    }

}