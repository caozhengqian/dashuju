package com.pateo.appframework.common.adapter.recycle;

/**
 *
 * @author fangxin
 * @date 2018-8-23
 */

public interface IItemRecycleListener {
    void setListener(RecyclerViewHolder holder);
}
