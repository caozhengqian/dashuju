package com.pateo.appframework.common.adapter.recyclebind;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.Collections;
import java.util.List;

/**
 * RecyclerView通用适配器
 *
 * @author fangxin
 * @date 2018-8-23
 */
public abstract class ComRecycleBindAdapter<T> extends RecyclerView.Adapter<RecyclerViewBindHolder> implements OnItemCallbackListener{
    private Context mContext;
    private int mLayoutId;
    private List<T> data;
    private IItemRecycleBindListener itemRcvBindListener;

    public ComRecycleBindAdapter(Context context, int layoutId, IItemRecycleBindListener itemRcvBindListener) {
        this(context, layoutId, null, itemRcvBindListener);
    }

    public ComRecycleBindAdapter(Context context, int layoutId, List<T> data, @NonNull IItemRecycleBindListener itemRcvBindListener) {
        mContext = context;
        mLayoutId = layoutId;
        this.data = data;
        this.itemRcvBindListener = itemRcvBindListener;
    }

    @Override
    public RecyclerViewBindHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        RecyclerViewBindHolder viewHolder = RecyclerViewBindHolder.get(mContext, parent, mLayoutId, itemRcvBindListener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewBindHolder holder, int position) {
//        RecyclerViewBindHolder.getItemBinding().setVariable(variableId,  (T)datas.get(position));
        convert(holder, (T) data.get(position));
    }

    /**
     * 需要自己实现的方法，这个方法，用来处理条目的显示效果
     *
     * @param holder 里面有布局文件的控件
     * @param t      每个条目对应的数据对象
     */
    public abstract void convert(RecyclerViewBindHolder holder, T t);

    @Override
    public int getItemCount() {
        return data != null ? data.size() : 0;
    }

    public void setData(List<T> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public synchronized void onMove(int fromPosition, int toPosition) {
        Collections.swap(data,fromPosition,toPosition);
        notifyItemMoved(fromPosition, toPosition);
    }

    @Override
    public void onSwipe(int position) {
        if(position < 0 || position > getItemCount()) {
            return;
        }
        data.remove(position);
        notifyItemRemoved(position);
    }

    public List<T> getData() {
        return data;
    }
}