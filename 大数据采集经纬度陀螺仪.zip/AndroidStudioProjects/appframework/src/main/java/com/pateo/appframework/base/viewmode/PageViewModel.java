package com.pateo.appframework.base.viewmode;

import android.content.Context;
import android.databinding.Bindable;
import android.databinding.ObservableArrayList;
import android.databinding.ObservableList;

import com.pateo.appframework.BR;
import com.pateo.appframework.base.bean.BasePage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Created by huangxiaodong on 2018/6/5.
 */

public class PageViewModel<T extends Comparable<? super T>> extends BaseViewModel{
    public final ObservableList<T> items = new ObservableArrayList<>();
    protected BasePage<List<T>> pageCache;

    public PageViewModel(Context mContext) {
        super(mContext);
        this.pageCache = new BasePage<>();
        this.pageCache.setPageData(new ArrayList<T>(100));
    }

    @Bindable
    public boolean isEmpty() {
        return items.isEmpty();
    }

    /**
     * 获取首页分页参数
     * @return
     */
    public BasePage getFirstPage(){
        BasePage page = new BasePage();
        return page;
    }


    /**
     * 获取下一页分页参数
     * @return
     */
    public BasePage getNextPage(){
        BasePage page = new BasePage();
        page.setPageIndex(pageCache.getPageIndex()+1);
        return page;
    }

    /**
     * 获取所有页
     * @return
     */
    public BasePage getWholePage(){
        BasePage page = new BasePage();
        if (pageCache.getPageData().size() > page.getPageSize()) {
            page.setPageSize(pageCache.getPageData().size());
        }
        return page;
    }

    public boolean hasMoreData(){
        return pageCache.getPageData().size() < pageCache.getTotalCount();
    }

    public List<T> onRefreshComplete(BasePage<List<T>> page){
        if (null != page && page.getPageIndex() <=  BasePage.FIRST_PAGE_INDEX) {
            pageCache.reset();
        }
        if (null == page || null == page.getPageData()){
            return pageCache.getPageData();
        }

        //首页数据
        if (page.getPageIndex() ==  BasePage.FIRST_PAGE_INDEX){
            pageCache.getPageData().addAll(page.getPageData());
            pageCache.setPageIndex(page.getPageIndex());
            pageCache.setTotalCount(page.getTotalCount());
            pageCache.setTotalPage(page.getTotalPage());

            items.clear();
            items.addAll(pageCache.getPageData());
            notifyPropertyChanged(BR.empty);
            return pageCache.getPageData();
        }

        //追加数据
        if (page.getPageIndex() - pageCache.getPageIndex() == 1){
//            removeDuplication(page.getPageData());
            pageCache.getPageData().addAll(page.getPageData());
            pageCache.setPageIndex(page.getPageIndex());
            pageCache.setTotalCount(page.getTotalCount());
            pageCache.setTotalPage(page.getTotalPage());
        }

        Collections.sort(pageCache.getPageData());

        items.clear();
        items.addAll(pageCache.getPageData());
        notifyPropertyChanged(BR.empty);
        return pageCache.getPageData();
    }

    private void removeDuplication(List<T> pageList){
        if (null == pageList || pageList.size() == 0){
            return;
        }

        for (T data : pageList){
            Iterator<T> it = pageCache.getPageData().iterator();
            while(it.hasNext()){
                T cacheData = it.next();
                if (cacheData.equals(data)){
                    it.remove();
                    break;
                }
            }
        }
    }
}
