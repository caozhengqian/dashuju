package com.pateo.appframework.common.adapter.recyclebind;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 *
 * @author fangxin
 * @date 2018-8-23
 */
public class RecyclerViewBindHolder extends RecyclerView.ViewHolder {
    private Context mContext;
    private View mConvertView;
    private SparseArray<View> mViews;
    private int layoutId;
    private ViewDataBinding itemBinding;

    public RecyclerViewBindHolder(Context mContext, View itemView, int layoutId, ViewDataBinding itemBinding) {
        super(itemView);
        this.mContext = mContext;
        this.mConvertView = itemView;
        this.mViews = new SparseArray<View>();
        this.layoutId = layoutId;
        this.itemBinding = itemBinding;
    }

    public static RecyclerViewBindHolder get(Context context, ViewGroup parent, int layoutId, @NonNull IItemRecycleBindListener itemListener) {
        ViewDataBinding itemBinding = DataBindingUtil.inflate(LayoutInflater.from(context), layoutId, parent, false);
        View itemView = itemBinding.getRoot();
        RecyclerViewBindHolder holder = new RecyclerViewBindHolder(context, itemView, layoutId, itemBinding);
        if (itemListener != null) {
            itemListener.setListener(holder);
        }
        return holder;
    }

    public ViewDataBinding getItemBinding() {
        return itemBinding;
    }

    public int getLayoutId() {
        return layoutId;
    }

    /**
     * 通过viewId获取控件
     *
     * @param viewId
     * @return
     */
    public <T extends View> T getView(int viewId) {
        View view = mViews.get(viewId);
        if (view == null) {
            view = mConvertView.findViewById(viewId);
            mViews.put(viewId, view);
        }
        return (T) view;
    }

    public RecyclerViewBindHolder setText(int viewId, String text) {
        TextView tv = getView(viewId);
        tv.setText(text);
        return this;
    }

    public RecyclerViewBindHolder setImageResource(int viewId,@DrawableRes int resId) {
        ImageView view = getView(viewId);
        view.setImageResource(resId);
        return this;
    }

    public RecyclerViewBindHolder setOnClickListener(int viewId, View.OnClickListener listener) {
        View view = getView(viewId);
        view.setOnClickListener(listener);
        return this;
    }
}
