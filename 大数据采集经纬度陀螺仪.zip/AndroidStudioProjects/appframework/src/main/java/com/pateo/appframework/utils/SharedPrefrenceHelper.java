package com.pateo.appframework.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static com.google.gson.internal.$Gson$Preconditions.checkNotNull;

/**
 * @author huangxiaodong
 * @date 2018/7/20
 */

public class SharedPrefrenceHelper {
    private static final String DEFAULT_FILE_NAME = "default_app_data";
    private Context context;
    private String filename;
    private static Gson gson = new Gson();
    private static SharedPrefrenceHelper sInstance = new SharedPrefrenceHelper();

    public static SharedPrefrenceHelper getInstance() {
        return sInstance;
    }

    private SharedPrefrenceHelper() {
        init(AppConfigure.getApplicationContext());
    }

    /***
     * 建议在application初始化
     * @param applicationContext
     */
    public void init(@NonNull Context applicationContext) {
        checkNotNull(applicationContext);
        if (null != applicationContext.getApplicationContext()) {
            this.context = applicationContext.getApplicationContext();
        } else {
            this.context = applicationContext;
        }
        this.filename = DEFAULT_FILE_NAME;
    }

    public boolean saveData(String key, Object obj) {
        SharedPreferences sp = context.getSharedPreferences(filename, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        if (obj instanceof String) {
            editor.putString(key, (String) obj);
        } else if (obj instanceof Integer) {
            editor.putInt(key, (Integer) obj);
        } else if (obj instanceof Boolean) {
            editor.putBoolean(key, (Boolean) obj);
        } else if (obj instanceof Float) {
            editor.putFloat(key, (Float) obj);
        } else if (obj instanceof Long) {
            editor.putLong(key, (Long) obj);
        } else {
            editor.putString(key, gson.toJson(obj));
        }
        return editor.commit();
    }

    public <T> T loadData(String key, T defaultObject) {
        return loadData(key,defaultObject.getClass(),defaultObject);
    }

    public <T> T loadData(String key, Type type, T defaultObject) {
        SharedPreferences sp = context.getSharedPreferences(filename, Context.MODE_PRIVATE);
        Object object;
        if (defaultObject instanceof String) {
            object = sp.getString(key, (String) defaultObject);
        } else if (defaultObject instanceof Integer) {
            object = sp.getInt(key, (Integer) defaultObject);
        } else if (defaultObject instanceof Boolean) {
            object = sp.getBoolean(key, (Boolean) defaultObject);
        } else if (defaultObject instanceof Float) {
            object = sp.getFloat(key, (Float) defaultObject);
        } else if (defaultObject instanceof Long) {
            object = sp.getLong(key, (Long) defaultObject);
        } else {
            String json = sp.getString(key, "");
            object = gson.fromJson(json, type);
            if (null == object) {
                object = defaultObject;
            }
        }
        return (T) object;
    }

    public <T> List<T> loadListData(String key) {
        SharedPreferences sp = context.getSharedPreferences(filename, Context.MODE_PRIVATE);
        List<T> tList;
        String json = sp.getString(key, "");
        tList = gson.fromJson(json, new TypeToken<List<T>>() {}.getType() );
        if (null == tList) {
            tList = new ArrayList<>();
        }
        return tList;
    }

    public boolean delete(String key) {
        SharedPreferences sp = context.getSharedPreferences(filename, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.remove(key);
        return editor.commit();
    }

    public boolean deleteAll(){
        SharedPreferences sp = context.getSharedPreferences(filename, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        return editor.commit();
    }
}
