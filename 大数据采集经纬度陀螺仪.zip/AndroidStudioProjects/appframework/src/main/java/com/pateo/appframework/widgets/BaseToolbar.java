package com.pateo.appframework.widgets;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.pateo.appframework.R;
import com.pateo.appframework.utils.AppLog;

/**
 * CustomToolbar
 *
 * @author fangxin
 * @date 2018/10/23
 */

public abstract class BaseToolbar extends Toolbar {
    private static final String TAG = "CustomToolbar";
    private View mChildView;
    private ImageView ivNavigation;
    private TextView tvTitle;
    private ImageView ivRight;
    private TextView tvRight;

    private Drawable navigationIcon;
    private String titleText;
    private String rightText;
    private Drawable rightIcon;

    public BaseToolbar(Context context) {
        this(context, null, 0);
    }

    public BaseToolbar(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BaseToolbar(final Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.mBaseToolbar);
        navigationIcon = typedArray.getDrawable(R.styleable.mBaseToolbar_tb_navigationIcon);
        titleText = typedArray.getString(R.styleable.mBaseToolbar_tb_title);
        rightText = typedArray.getString(R.styleable.mBaseToolbar_tb_rightText);
        rightIcon = typedArray.getDrawable(R.styleable.mBaseToolbar_tb_rightIcon);
        typedArray.recycle();
        initView();
        setNavigationOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Activity activity = (Activity) context;
                activity.onBackPressed();
            }
        });
    }

    private void initView() {
        if (mChildView == null) {
            mChildView = View.inflate(getContext(), R.layout.mybasetoolbar, null);
            ivNavigation = mChildView.findViewById(R.id.toolbar_ivNavigation);
            tvTitle = mChildView.findViewById(R.id.toolbar_tvTitle);
            tvRight = mChildView.findViewById(R.id.toolbar_rightText);
            ivRight = mChildView.findViewById(R.id.toolbar_ivRight);
            LayoutParams layoutParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL);
            addView(mChildView, layoutParams);
            if(navigationIcon != null) {
                ivNavigation.setImageDrawable(navigationIcon);
            }
            if(super.getTitle() != null){
                tvTitle.setText(super.getTitle());
            }
            if(titleText != null) {
                tvTitle.setText(titleText);
            }
            if(rightText != null) {
                tvRight.setText(rightText);
            }
            if(rightIcon != null) {
                ivRight.setVisibility(VISIBLE);
                ivRight.setImageDrawable(rightIcon);
            }
            super.setLogo(android.R.color.transparent);
        }
    }

    @Override
    public void setTitle(CharSequence title) {
        super.setTitle(title);
        AppLog.d(TAG,"setTitle",title,tvTitle);
        if(tvTitle != null){
            tvTitle.setText(title);
        }
    }

    @Override
    public void setLogo(int resId) {
        //super.setLogo(resId);
    }

    @Override
    public void setNavigationIcon(int resId) {
        //super.setNavigationIcon(resId);
        ivNavigation.setImageResource(resId);
    }

    @Override
    public void setNavigationIcon(Drawable navigationIcon) {
        ivNavigation.setImageDrawable(navigationIcon);
    }

    @Override
    public void setNavigationOnClickListener(OnClickListener listener) {
        ivNavigation.setOnClickListener(listener);
    }

    public void setIvRightIcon(int resId) {
        ivRight.setImageResource(resId);
    }

    public void setTvRightText(CharSequence rightText) {
        tvRight.setText(rightText);
    }

    public abstract Drawable defNavigationIcon();
}
