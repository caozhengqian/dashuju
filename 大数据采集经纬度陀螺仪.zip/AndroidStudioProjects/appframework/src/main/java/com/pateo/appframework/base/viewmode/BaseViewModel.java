package com.pateo.appframework.base.viewmode;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.Observable;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;

import com.pateo.appframework.base.model.IModelCallback;

/**
 * Created by huangxiaodong on 2018/7/19.
 */

public class BaseViewModel extends BaseObservable {
    public ObservableBoolean dataLoading = new ObservableBoolean();
//    public ObservableField<VMDataLoading> dataLoading;
    public ObservableField<VMErrorMsg> error = new ObservableField<>();
    public ObservableField<VMErrorMsg> tokenExpired = new ObservableField<>();

    // To avoid leaks, this must be an Application Context.
    protected final Context mContext;

    public BaseViewModel(Context mContext) {
        this.mContext = mContext.getApplicationContext();

//        error = new ObservableField<>(new VMErrorMsg());
//        dataLoading = new ObservableField<>(new VMDataLoading());
//        tokenExpired = new ObservableField<>(new VMErrorMsg());
    }

//    public static class VMDataLoading{
//        public boolean dataLoading;
//        public String loadingPrompt;
//    }

    public void addChildViewModel(final BaseViewModel... viewModels) {
        for (final BaseViewModel childViewModel : viewModels) {
            childViewModel.getDataLoading().addOnPropertyChangedCallback(new OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable sender, int propertyId) {
                    dataLoading.set(childViewModel.getDataLoading().get());
                }
            });
            childViewModel.error.addOnPropertyChangedCallback(new OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable sender, int propertyId) {
                    error.set(childViewModel.error.get());
                }
            });
            childViewModel.tokenExpired.addOnPropertyChangedCallback(new OnPropertyChangedCallback() {
                @Override
                public void onPropertyChanged(Observable sender, int propertyId) {
                    tokenExpired.set(childViewModel.tokenExpired.get());
                }
            });
        }
    }

    public static class VMErrorMsg{
        public String errorCode;
        public String errorMsg;

        public VMErrorMsg(String errorCode, String errorMsg) {
            this.errorCode = errorCode;
            this.errorMsg = errorMsg;
        }
    }

    protected abstract class SimpleModelCallback<T> implements IModelCallback<T>{

        @Override
        public void onSuccess(T t) {
            dataLoading.set(false);
        }

        @Override
        public void onFailure(String errorCode, String errorMsg) {
            error.set(new VMErrorMsg(errorCode,errorMsg));
            dataLoading.set(false);
        }

        @Override
        public void onTokenExpired(String errorCode, String errorMsg) {
            tokenExpired.set(new VMErrorMsg(errorCode,errorMsg));
            dataLoading.set(false);
        }
    }

    public ObservableBoolean getDataLoading() {
        return dataLoading;
    }
}
