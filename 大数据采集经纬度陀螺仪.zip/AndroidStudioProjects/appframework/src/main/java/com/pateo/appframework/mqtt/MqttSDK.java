package com.pateo.appframework.mqtt;

import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

/**
 * Created by huangxiaodong on 2018/8/21.
 */

public class MqttSDK {
    private static MqttConfigParams sMqttConfig;
    private static MqttAsyncClient sMqttClient;

    public static void initialize(MqttConfigParams config){
        sMqttConfig = config;
    }

    public static MqttAsyncClient buildClient(){
        if (null == sMqttConfig){
            return null;
        }
        String serverUrl = sMqttConfig.isLogEnabled()? sMqttConfig.getDebugUrl(): sMqttConfig.getReleaseUrl();
        MemoryPersistence persistence = new MemoryPersistence();
        try {
            MqttAsyncClient sMqttClient = new MqttAsyncClient(serverUrl, sMqttConfig.getClientId(),persistence);
            return sMqttClient;
        } catch (MqttException e) {
            e.printStackTrace();
            return null;
        }
    }

//    public static <T extends ICheckResponse,V> void subscribe(final String topic, final int qos, final MqttSubscribeCallback<T,V> callback) {
//        final ErrorDetail errorBusy = ErrorInjector.getError(ErrorDetail.ERROR_BUSY, "");
//
//        //构造mqtt client
//        if (null == sMqttClient) {
//            sMqttClient = MqttSDK.buildClient();
//            if (null == sMqttClient) {
//                callback.onBusiFailed(topic, errorBusy.errorCode, errorBusy.errorMsg);
//                return;
//            }
//        }
//
//        //连服务器
//        if (!sMqttClient.isConnected()) {
//            MqttConnectOptions connOpts = new MqttConnectOptions();
//            connOpts.setCleanSession(true);
//            connOpts.setAutomaticReconnect(true);
//            try {
//                sMqttClient.connect(connOpts, new IMqttActionListener() {
//                    @Override
//                    public void onSuccess(IMqttToken asyncActionToken) {
//                        subscribeImpl(topic, qos, callback);
//                    }
//
//                    @Override
//                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                        callback.onBusiFailed(topic, errorBusy.errorCode, errorBusy.errorMsg);
//                    }
//                });
//            } catch (MqttException e) {
//                callback.onBusiFailed(topic, errorBusy.errorCode, errorBusy.errorMsg);
//                return;
//            }
//        } else {
//            subscribeImpl(topic, qos, callback);
//        }
//    }
//
//    public static void unsubscribe(final String topic) {
//        if (null != sMqttClient && sMqttClient.isConnected()) {
//            try {
//                sMqttClient.unsubscribe(topic);
//                AppLog.d("mqtt unsubscribe"+topic+" success");
//            } catch (MqttException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    public static void disconnect() {
//        if (null != sMqttClient) {
//            try {
//                sMqttClient.disconnect();
//                AppLog.d("mqtt disconnect success");
//            } catch (MqttException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    private static void subscribeImpl(String topic, int qos, MqttSubscribeCallback callback) {
//        try {
//            sMqttClient.subscribe(topic, qos, null,new IMqttActionListener() {
//                @Override
//                public void onSuccess(IMqttToken asyncActionToken) {
//                    AppLog.d("mqtt subscribe success");
//                }
//
//                @Override
//                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
//                    AppLog.d("mqtt subscribe failure",exception.getMessage());
//                }
//            },callback);
//        } catch (MqttException e) {
//            callback.onBusiFailed(topic, ErrorDetail.ERROR_BUSY, ErrorInjector.getErrorMsg(ErrorDetail.ERROR_BUSY));
//        }
//    }
}
