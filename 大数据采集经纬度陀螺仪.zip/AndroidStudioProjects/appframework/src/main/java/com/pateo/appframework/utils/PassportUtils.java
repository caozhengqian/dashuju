package com.pateo.appframework.utils;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.pateo.appframework.utils.AppLog;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by huangxiaodong on 17-7-21.
 */

public class PassportUtils {

    /**
     * 读取meta值
     * @param context
     * @param key
     * @return
     */
    public static String getMeta(Context context, String key) {
        if (context == null || TextUtils.isEmpty(key)) {
            return null;
        }
        Object ret = null;
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager != null) {
                ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
                if (applicationInfo != null && applicationInfo.metaData != null) {
                    ret = applicationInfo.metaData.get(key);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (null == ret)? null : ret.toString();
    }

    /**
     * 将字符串转换成Bitmap类型
     * @param string String s = "data:image/jpg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAA3AKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD0EU8U0U8UAOFPFNFNeeGJgskqISMgMwHFAEwp4rPk1nTYXVZL2BdxwCXGM+melXxIuM5FOz3AkFPFc1q3jjQdFm8i4vVkuSdoggHmPn0IHQ/XFdDbzCeCOUKyh1DbWGCMjofetJ0akIqcotJ7efoK6ZOKcKbkCqV1rml2Mwhur+3ilPRHkAP5VEYyk7RVxmkKeKhE8XliQyIEIyGJ4NQSaxpsP372D6BwT+lSBoCnisb/AISGzdgttFc3THoIoT/XFPFzrVz/AKixgtl/vXEm4/ktArmyKZNc29qu64njiX1dgP51mDSr64/4/NWnx/ct1EQ/Pkmp7fQNMgbeLRJJO7y5cn86AGHxFZMxW0S4vHHa3iLfrwKUXWuXP+o0+C1X+9cy7j/3ytayKFUKoAA6ACpBQAy2WVYEE7q8oHzsowCfYVYFNFPFAzihTxTRSTSrBBJK3RFLGgDOudUne7eysYd0wOC5PC+pqS30aJMzXZ+0zt1L8gfQVV0BQkNxfzsq72xuY49z+p/Sn3Wv738jT4WmkPG7HH4DvQT5swvFenwXgETHy4djRtEqjac4wfYggYNeY/2D4kiLWkM8xtwcDbOQhH0zXsJ0O8ucz3kuHP8ACOcf0FcP45W50rTiY7iRC7BRtbH8q9rKMdiqdSOGo2ak1urpPuROKa5mZPhvwrcWGsQ3l8ImWE7kjDZJbsa9TfWNThspJ1tkjijQszOcnAGeBXn/AMO9PaeL7TISzSOTuY5zjivSdWgK6cyAZBXBHrUZziatbGSVaXNy6aK22+mo6cbR0PNJPHF34iuzbw+eY9uWaSYxKPwTr+dYGsXn9lSILe109mfJ3+RlgfqxNZ+owy6Bq7vbupQk4U+noaqy6n9o1GK5uYMomP3YOBX1GEwCdSFbCxvQcb2vq3bZ3e9/kYSlpaW5754Qs7a90W0lvbdJLkxguW6Z+nSuujtbO2XMdvBGB3VAK43wLq1pqekLcWzcKdrqeqn0rhfip4q1IayNLtrmSC2WMM2xsFyff0r5TCZbWxuMeHtyPVu/T5G8pKMbnqOsfEDw3obbLrUonlHWKD94w+uOn41t6RqtvrOmwX9qW8iZdyFhgkfSvB/DnhXTZ7aOW8ia6mlUMSzEBc+mP517NoMa2WmQ28a7YokCqPQVOOp4KkvZ4eUpST1bsl8lv944uT1Z0DTRxDLuqj1Y4rK1Dxf4f0ri81a0jYdV8wFvyFeLfF+/vzr8AW4lW0aHCqrEDcDz+mKwNL0zwu1vHJf6jI0jDLDftCn6YzXo0Mlo/VoYmtNtS6Rjd/f/AMAh1HdxSPpzTtQttUsoryzlEtvMu6NwMbh61dFcn4MvLCfRLeLTZ0mtYVEalWzjHr711i9K8CrFRm4pNWfXf5mq2HiniminisxnFCmXSubSUJGkjbThHGQ3tUgp4oA5620O5ugpvJDFEOViTt+HQVvWlnb2abIIlQdz3P1NTCnCgSVgf7pryH4rvm3tlHTzT/KvXnHyGvM/H+iTaskccTBSr7skdq9HKa9OhjadWo7RT1JqJuLSJ/hpEDols2Ox/ma77UIg1qwI7VyvgXTG0zTYrYsX2Z+bGM856V2lxF5kJX2rnxlSNTE1KkdnJtfNlRVkkfNviy1ez8TzNLkxO+5T7elPvJrL7CWaWOTeuFUHJ6fpXofinw0t47eZFuXOR6iuVh8F2yv/AKuWQ+jNx+le5HM8JXpUXiXJTpaLltqv0fcy5JJu3Uf8LLu4t9Suo13eRJHz6bhS/EbT5J7hb1VJZBtb6V2/hfw8bXGI9o9AK09f0D7RCSq5OK5audSeY/XqcbeXdWtr6opU/c5WefeCPGWjWFksGru0MkXAcIWDD8O9dpovxO0jVvEA0mGNo4JExDO/G5/QjsCK4pvBtoLktJZZ55AJANdf4f0C0gkTZp0CYOR8lXisRlNRzqU6c+aXmkk/IUVUWjZX8c6EL+NjIuUHIPp715Y+i2EKs0t9hR6EV9H31ks1mQ654714xqHw/gjvpGSWZkZiQmAMZPSpynMHh4yjOtKEd7JXv332CpC/S434QarcWPip7ZCzWs8ZDjsCOh+tfSED70BryDwZ4a+wTBo4dg/WvXbRCkSg1zZvjoY7FOvCPKnb1durKpxcY2ZZFOFIKcK8ws4sU8UUUAPFOFFFADsZFUbrTo7g5YCiigCezsktxhRWgBxiiigCtPYxzj5lFVk0SBWztFFFAGlBaRxDCqKneBZFwRRRQBTbR7dmyUFWYNPii+6ooooAsyW6um0is5tDgeTcVFFFAGha6fFABtUVoKMCiigCQU4UUUAf/9k";
     * @return
     */
    public static Bitmap base64ToBitmap(String string){
        String base64 = string.replace("data:image/jpg;base64,","")
                .replace("data:image/png;base64,","");
        Bitmap bitmap=null;
        try {
            byte[] bitmapArray;
            bitmapArray= Base64.decode(base64, Base64.DEFAULT);
            bitmap= BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            AppLog.e(" base64字符串格式错误");
            e.printStackTrace();
        }
        return bitmap;
    }

    /**
     * 将Bitmap转换成字符串
     * @param bitmap
     * @return
     */
    public static String bitmaptoString(Bitmap bitmap){

        String string=null;
        ByteArrayOutputStream bStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,100,bStream);
        byte[]bytes=bStream.toByteArray();
        string=Base64.encodeToString(bytes,Base64.DEFAULT);
        return string;
    }

    public static String md5(String str) {
        MessageDigest messageDigest = null;
        StringBuffer md5StrBuff = new StringBuffer();
        try {
            messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.reset();
            messageDigest.update(str.getBytes("UTF-8"));

            byte[] byteArray = messageDigest.digest();
            for (int i = 0; i < byteArray.length; i++) {
                if (Integer.toHexString(0xFF & byteArray[i]).length() == 1){
                    md5StrBuff.append("0").append(
                            Integer.toHexString(0xFF & byteArray[i]));
                } else {
                    md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
                }
            }
        } catch (NoSuchAlgorithmException e) {
            System.exit(-1);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return md5StrBuff.toString();
    }

    public static String encryption(String password){
        String password100 = password;
        for (int i=0;i<100;i++){
            password100 = md5(password100+i);
        }
        return password100;
    }


    public static boolean isEmailValid(String email) {
        return email.contains("@");
    }

    public static boolean isPhoneValid(String phone, String rule) {
        rule = rule.replace("/","");
        return phone.matches(rule);
    }

    public static boolean isNicknameValid(String nickname) {
        return (TextUtils.isEmpty(nickname) || nickname.length() < 4)?false:true;
    }


//    public static int isPasswordValid(String password) {
//        if (TextUtils.isEmpty(password)){
//            return R.string.error_invalid_password_short;
//        }
//        if (password.length() < 8){
//            return R.string.error_invalid_password_short;
//        }
//        boolean has_number = false;
//        boolean has_letter = false;
//        for(int i = 0; i < password.length(); i++){
//            char ch = password.charAt(i);
//            if (!has_number) {
//                if (ch >= '0' && ch <= '9') {
//                    has_number = true;
//                }
//            }
//            if (!has_letter){
//                if (ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z') {
//                    has_letter = true;
//                }
//            }
//            if (has_number && has_letter){
//                break;
//            }
//        }
//        if (has_number && has_letter){
//            return 0;
//        }
//        return R.string.error_invalid_password;
//    }


    public static void changeStatusbar(Activity activity, boolean light, int colorArgb){
        Window window = activity.getWindow();
        if(Build.VERSION.SDK_INT >= 21){
            int systemUIFlag = window.getDecorView().getSystemUiVisibility();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            if(light){
                systemUIFlag |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;  /// View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
                window.getDecorView().setSystemUiVisibility(systemUIFlag);
                window.setStatusBarColor(colorArgb);
            }else{
                systemUIFlag = systemUIFlag & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                window.getDecorView().setSystemUiVisibility(systemUIFlag);
                window.setStatusBarColor(colorArgb);
            }
        }
    }


    /**
     * Get a file path from a Uri. This will get the the path for Storage Access
     * Framework Documents, as well as the _data field for the MediaStore and
     * other file-based ContentProviders.
     *
     * //@param context The context.
     * //@param uri The Uri to query.
     * //@author paulburke
     * http://blog.csdn.net/tempersitu/article/details/20557383
     */
    public static String getPath(final Context context, final Uri uri) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {
                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[] {
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            // Return the remote address
            if (isGooglePhotosUri(uri))
                return uri.getLastPathSegment();

            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * //@param context The context.
     * //@param uri The Uri to query.
     * //@param selection (Optional) Filter used in the query.
     * //@param selectionArgs (Optional) Selection arguments used in the query.
     * //@return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }


    /**
     * //@param uri The Uri to check.
     * //@return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * //@param uri The Uri to check.
     * //@return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * //@param uri The Uri to check.
     * //@return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is Google Photos.
     */
    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    public static byte[] bmpToByteArray(Bitmap mBitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();// outputstream
        mBitmap.compress(Bitmap.CompressFormat.JPEG, 30, baos);
        return baos.toByteArray();// 转为byte数组
    }
}
