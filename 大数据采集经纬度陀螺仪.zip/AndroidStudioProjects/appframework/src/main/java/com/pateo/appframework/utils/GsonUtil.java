package com.pateo.appframework.utils;

import com.google.gson.Gson;

import java.lang.reflect.Type;

/**
 * Created by huangxiaodong on 2018/10/29.
 */

public class GsonUtil {
    private static final Gson GSON = new Gson();
    public static Gson gson(){
        return GSON;
    }

    public static <T> T copy(T obj, Type type) {
        if (null == obj){
            return null;
        }

        String json = GSON.toJson(obj);
        return GSON.fromJson(json,type);
    }
}
