package com.pateo.appframework.network.monitor;

import java.io.IOException;

/**
 * @author huangxiaodong
 * @date 2018/7/20
 */

public class NoNetworkException extends IOException {
}
