package com.pateo.appframework.widgets;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * @author huangxiaodong
 * @date 2018/4/24
 */
@Deprecated
public class CustomToolbar extends Toolbar {
    private TextView tvTitle;
    private TextView tvNavigation;

    public CustomToolbar(Context context) {
        this(context,null);
    }

    public CustomToolbar(Context context, @Nullable AttributeSet attrs) {
        this(context,attrs,0);
    }

    public CustomToolbar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        tvTitle = new TextView(getContext());
        LayoutParams lpTitle = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        addView(tvTitle, lpTitle);

        tvNavigation = new TextView(getContext());
        LayoutParams lpNav = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL | Gravity.LEFT);
        addView(tvNavigation, lpNav);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();


//        tvTitle = findViewById(R.id.tv_toolbar_title);
//        tvNavigation = findViewById(R.id.tv_toolbar_navigation);
    }

    public void setCenterTitle(CharSequence title) {
        setTitle(title);
        if (null != tvTitle) {
            tvTitle.setText(title);
            setTitle("");
        }
    }

    public void setCenterTitle(int resId) {
        String title = getResources().getString(resId);
        setTitle(title);
        if (null != tvTitle) {
            tvTitle.setText(title);
            setTitle("");
        }
    }

    @Override
    public void setNavigationIcon(int resId) {
        super.setNavigationIcon(resId);
        tvNavigation.setText(null);
    }

    @Override
    public void setNavigationIcon(@Nullable Drawable icon) {
        super.setNavigationIcon(icon);
        tvNavigation.setText(null);
    }

    public void setNavigationText(String text) {
        setNavigationIcon(null);
        tvNavigation.setText(text);
    }

    public void setNavigationText(int resId) {
        setNavigationIcon(null);
        String title = getResources().getString(resId);
        tvNavigation.setText(title);
    }

    @Override
    public void setNavigationOnClickListener(OnClickListener listener) {
        super.setNavigationOnClickListener(listener);
        tvNavigation.setOnClickListener(listener);
    }
}
