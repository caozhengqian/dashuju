package com.pateo.appframework.base.view;

import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.pateo.appframework.base.viewmode.BaseViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangxiaodong on 2018/8/29.
 */

public class BaseFragmentPagerAdapter<F extends BaseFragment,V extends BaseViewModel> extends FragmentPagerAdapter {
    private List<F> mFragments;
    private V mViewModel;

    public BaseFragmentPagerAdapter(FragmentManager fm, List<F> fragments, V viewmodel) {
        super(fm);
        mViewModel = viewmodel;
        if (null == fragments){
            mFragments = new ArrayList<>(5);
        } else {
            mFragments = fragments;
        }
    }

    @Override
    public Fragment getItem(int position) {
        BaseFragment fg = mFragments.get(position);
        return fg;
    }

    @Override
    public int getCount() {
        return mFragments.size();
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    public void replaceData(List<F> fragments){
        if (null == fragments){
            mFragments.clear();
        } else {
            mFragments = fragments;
        }
        for (F f:mFragments){
            f.setViewModel(mViewModel);
        }
        notifyDataSetChanged();
    }
}