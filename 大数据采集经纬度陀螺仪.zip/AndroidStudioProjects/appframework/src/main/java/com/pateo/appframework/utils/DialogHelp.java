package com.pateo.appframework.utils;

import android.app.AlertDialog;
import android.support.v4.app.FragmentActivity;

/**
 * DialogHelp
 *
 * @author fangxin
 * @date 2018/11/8
 */

public class DialogHelp {

    public static AlertDialog.Builder builderDialog(FragmentActivity mActivity){

        return new AlertDialog.Builder(mActivity);
    }
}
