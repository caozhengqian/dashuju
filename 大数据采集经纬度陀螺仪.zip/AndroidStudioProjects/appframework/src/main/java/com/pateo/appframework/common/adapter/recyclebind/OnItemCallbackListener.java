package com.pateo.appframework.common.adapter.recyclebind;

/**
 * ItemCallback
 *
 * @author fangxin
 * @date 2018/10/15
 */

public interface OnItemCallbackListener {
    /**
     * @param fromPosition 起始位置
     * @param toPosition 移动的位置
     */
    void onMove(int fromPosition, int toPosition);

    void onSwipe(int position);
}
