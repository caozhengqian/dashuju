package com.pateo.appframework.utils;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.pateo.appframework.BuildConfig;

import java.lang.reflect.Field;


/**
 * Created by huangxiaodong on 2018/7/19.
 */

public class AppConfigure {
    private static Boolean sIsDebugMode;
    private static Context sApplicationContext;
    /**
     * 是否警告检查代码规范
     */
    public static final boolean IS_CHECK_WARN = BuildConfig.DEBUG && true;
    /**
     * 强制检查代码
     */
    public static final boolean IS_CHECK_CONSTRAINT = BuildConfig.DEBUG && false;

    public static void init(Application application){
        sApplicationContext = application.getApplicationContext();
    }

    public static boolean isDebugMode(){
//        return true;
        if (null != sIsDebugMode){
            return sIsDebugMode;
        }
        try{
            String packageName = sApplicationContext.getPackageName();
            Class clz = Class.forName(packageName + ".BuildConfig");
            Field field = clz.getDeclaredField("BUILD_TYPE");
            String buildType = (String)field.get(null);
            sIsDebugMode = buildType.equals("debug");
            return sIsDebugMode;
        }catch (Exception e){
            e.printStackTrace();
        }

        if (null != sApplicationContext) {
            ApplicationInfo info = sApplicationContext.getApplicationInfo();
            sIsDebugMode = ((info.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0);
        }

        return (null == sIsDebugMode)?true:sIsDebugMode;
    }


    public static Context getApplicationContext(){
        return sApplicationContext;
    }

    public static String getPackageName(){
        if (null == sApplicationContext){
            return "";
        }
        return sApplicationContext.getPackageName();
    }

    public static String getDeviceId() {
        return "1234567890ABCDEF";
    }

    public static String getDeviceBrand() {
        return android.os.Build.BRAND;
    }

    public static String getDeviceROM() {
        return "";
    }

    public static String getDeviceOSVersion() {
        return Build.VERSION.SDK_INT + Build.VERSION.RELEASE;
    }

    public static int[] getScreenWH(Context context) {
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        int[] wh = {displayMetrics.widthPixels, displayMetrics.heightPixels};
        return wh;
    }

}
