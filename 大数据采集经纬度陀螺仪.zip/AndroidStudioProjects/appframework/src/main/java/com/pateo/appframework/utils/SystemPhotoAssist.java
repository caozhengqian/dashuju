package com.pateo.appframework.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.app.Activity.RESULT_OK;

/**
 * Created by huangxiaodong on 18-1-12.
 */

public class SystemPhotoAssist {
    private static final int REQUEST_SELECT_IMAGE_KITKAT = 1;
    private static final int REQUEST_SELECT_IMAGE = 2;
    private static final int REQUEST_IMAGE_CROP = 3;
    private static final int REQUEST_IMAGE_CAPTURE = 4;

    private static String  mHeadimagePath;
    private int mCropWidth;
    private int mCropHeight;

    private SystemPhotoAssist(Fragment fg) {
        this.mCropWidth = 512;
        this.mCropHeight = 512;
    }

    private void setCropSize(int width,int height){
        this.mCropWidth = width;
        this.mCropHeight = height;
    }

    public static void openAlbum(TargetInterface target){
        if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.KITKAT){
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/jpeg");
            if (target instanceof Fragment){
                Fragment fg = (Fragment)target;
                fg.startActivityForResult(intent, REQUEST_SELECT_IMAGE_KITKAT);
            }
        }else{
            Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/jpeg");
            if (target instanceof Fragment) {
                Fragment fg = (Fragment) target;
                fg.startActivityForResult(intent, REQUEST_SELECT_IMAGE);
            }
        }
    }

    public static void openCamera(TargetInterface target){
        Context context = null;
        if (target instanceof Fragment) {
            Fragment fg = (Fragment) target;
            context = fg.getContext();
        } else if (target instanceof Activity){
            context = ((Activity)target);
        }
        Uri uri = FileProvider.getUriForFile(context,
                context.getPackageName()+ ".fileprovider",createImageFile());

        Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        if (target instanceof Fragment) {
            Fragment fg = (Fragment) target;
            fg.startActivityForResult(captureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    public static void onActivityResult(TargetInterface target,int requestCode, int resultCode, Intent data) {
        Context context = null;
        if (target instanceof Fragment) {
            Fragment fg = (Fragment) target;
            context = fg.getContext();
        } else if (target instanceof Activity){
            context = ((Activity)target);
        }
        if (requestCode == REQUEST_SELECT_IMAGE){
            if (resultCode != RESULT_OK) {
                return;
            }
            target.onImageSelected(data.getData());
        } else if (requestCode == REQUEST_SELECT_IMAGE_KITKAT){
            if (resultCode != RESULT_OK) {
                return;
            }
            String uriPath = PassportUtils.getPath(context,data.getData());
            Uri uri = FileProvider.getUriForFile(context,
                    context.getPackageName()+ ".fileprovider",new File(uriPath));
            target.onImageSelected(uri);
        } else if (requestCode == REQUEST_IMAGE_CROP){
            if (resultCode != RESULT_OK) {
                return;
            }
            Uri uri = FileProvider.getUriForFile(context,
                    context.getPackageName()+ ".fileprovider",new File(mHeadimagePath));
            target.onImageCropped(uri);
       } else if (requestCode == REQUEST_IMAGE_CAPTURE) {
            if (resultCode != RESULT_OK) {
                return;
            }
            Uri uri = FileProvider.getUriForFile(context,
                    context.getPackageName()+ ".fileprovider",new File(mHeadimagePath));
            target.onImageCaptured(uri);
        }
    }

    public static void cropImage(Fragment target, Uri uri){
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setDataAndType(uri,"image/*");
        intent.putExtra("crop","true");
        intent.putExtra("aspectX",1);
        intent.putExtra("aspectY",1);
        intent.putExtra("outputX",512);
        intent.putExtra("outputY",512);
        intent.putExtra("scale", true);  // 去黑边
        intent.putExtra("scaleUpIfNeeded", true);  // 去黑边
        Uri outUri = Uri.fromFile(createImageFile());
        intent.putExtra(MediaStore.EXTRA_OUTPUT, outUri);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        target.startActivityForResult(intent, REQUEST_IMAGE_CROP);
    }


    public static File createImageFile() {
        mHeadimagePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/passport";
        File passportDir = new File(mHeadimagePath);
        if (!passportDir.exists()){
            passportDir.mkdir();
        }
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        mHeadimagePath += "/image_"+timestamp+".jpg";
        return new File(mHeadimagePath);
    }
    public interface TargetInterface{
        void onImageSelected(Uri uri);
        void onImageCropped(Uri uri);
        void onImageCaptured(Uri uri);
    }
}
