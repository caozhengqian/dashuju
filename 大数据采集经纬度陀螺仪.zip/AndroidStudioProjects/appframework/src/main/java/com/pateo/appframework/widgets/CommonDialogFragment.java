package com.pateo.appframework.widgets;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.pateo.appframework.utils.AppLog;

/**
 * @author huangxiaodong
 * @date 2018/4/3
 */

public class CommonDialogFragment extends DialogFragment {
    public static CommonDialogFragment newInstance() {
        CommonDialogFragment dialog = new CommonDialogFragment();
        return dialog;
    }

    private static CommonDialogFragment sChargeInfoDialog = new CommonDialogFragment();
    private static CommonDialogFragment sLoadingDialog = new CommonDialogFragment();

    public static CommonDialogFragment getsChargeInfoDialog() {
        return sChargeInfoDialog;
    }

    public static CommonDialogFragment getsLoadingDialog() {
        return sLoadingDialog;
    }

    protected DialogInterface.OnDismissListener dismissListener;
    protected DialogInterface.OnCancelListener cancelListener;
    protected DialogInterface.OnClickListener clickListener;
    protected DialogGenerator dialogGenerator;
    protected DialogResizer dialogResizer;
    private boolean showing = false;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (null == dialogGenerator) {
            return super.onCreateDialog(savedInstanceState);
        }
        return dialogGenerator.generateDialog(getActivity(), savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (null != dialogResizer) {
            dialogResizer.resizeDialog(getDialog());
        }
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (null != dismissListener) {
            dismissListener.onDismiss(dialog);
        }
        showing = false;
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        if (null != cancelListener) {
            cancelListener.onCancel(dialog);
        }
        showing = false;
    }

    @Override
    public void dismiss() {
        AppLog.d(this.getClass().getSimpleName(), "dismiss,isAdded=" + isAdded() + ",showing=" + showing);
        if (showing) {
            try {
                super.dismiss();
            } catch (IllegalStateException ignore) {
            }
            showing = false;
        }
    }

    @Override
    public void dismissAllowingStateLoss() {
        AppLog.d(this.getClass().getSimpleName(), this + ",dismissAllowingStateLoss,isAdded=" + isAdded() + ",showing=" + showing);
        if (showing) {
            super.dismissAllowingStateLoss();
            showing = false;
        }
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        AppLog.d(this.getClass().getSimpleName(), this + ",show,isAdded=" + isAdded() + ",showing=" + showing);
        if (!isAdded() && !showing) {
            showing = true;
            try {
                super.show(manager, tag);
            } catch (IllegalStateException ignore) {
            }
        }

    }

    @Override
    public int show(FragmentTransaction transaction, String tag) {
        AppLog.d(this.getClass().getSimpleName(), this + ",show,isAdded=" + isAdded() + ",showing=" + showing);
        if (!isAdded() && !showing) {
            showing = true;
            try {
                return super.show(transaction, tag);
            } catch (IllegalStateException ignore) {
            }
        }
        return -1;
    }

    @Override
    public void showNow(FragmentManager manager, String tag) {
        AppLog.d(this.getClass().getSimpleName(), this + ",showNow,isAdded=" + isAdded() + ",showing=" + showing);
        if (!isAdded() && !showing) {
            showing = true;
            try {
                super.showNow(manager, tag);
            } catch (IllegalStateException ignore) {
            }
        }
    }

    public CommonDialogFragment setOnCancelListener(DialogInterface.OnCancelListener listener) {
        cancelListener = listener;
        return this;
    }

    public CommonDialogFragment setOnDismissListener(DialogInterface.OnDismissListener listener) {
        dismissListener = listener;
        return this;
    }

    public CommonDialogFragment setOnClickListener(DialogInterface.OnClickListener listener) {
        clickListener = listener;
        return this;
    }

    public CommonDialogFragment setDialogGenerator(DialogGenerator generator) {
        dialogGenerator = generator;
        return this;
    }

    public CommonDialogFragment setDialogResizer(DialogResizer resizer) {
        dialogResizer = resizer;
        return this;
    }

    public interface DialogGenerator {
        Dialog generateDialog(Context context, Bundle savedInstanceState);
    }

    public interface DialogResizer {
        void resizeDialog(Dialog dialog);
    }
}
