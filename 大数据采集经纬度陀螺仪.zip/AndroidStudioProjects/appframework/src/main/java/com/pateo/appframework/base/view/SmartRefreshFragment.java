package com.pateo.appframework.base.view;

import android.arch.lifecycle.Observer;
import android.databinding.ViewDataBinding;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.pateo.appframework.base.viewmode.BaseViewModel;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.constant.SpinnerStyle;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.scwang.smartrefresh.layout.header.ClassicsHeader;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;


/**
 * @author huangxiaodong
 * @date 2018/4/24
 */

public abstract class SmartRefreshFragment<T extends BaseActivity, B extends ViewDataBinding,VM extends BaseViewModel>
        extends BaseFragment<T, B,VM> implements OnRefreshListener, OnLoadMoreListener {
    protected SmartRefreshLayout mRefreshView;
    protected ClassicsHeader mRefreshHeader;
    protected ClassicsFooter mRefreshFooter;

    @Override
    protected void initSmartRefreshLayout() {
        mRefreshView = obtainRefreshView();
        if (null != mRefreshView) {
            mRefreshView.setOnRefreshListener(this);
            mRefreshView.setOnLoadMoreListener(this);
            setEnableRefresh(canRefresh());
            setEnableLoadMore(canLoadMore());


//            ClassicsHeader.REFRESH_HEADER_RELEASE = getString(R.string.cube_myptr_release_to_refresh);
//            ClassicsHeader.REFRESH_HEADER_UPDATE = getString(R.string.cube_myptr_ago);
//            int color = ContextCompat.getColor(getContext(), R.color.text_color_hint);
//            float size = getContext().getResources().getDimension(R.dimen.text_size13);
//            mRefreshHeader.setAccentColor(color);
//            mRefreshHeader.setTextSizeTime(13);
//            mRefreshHeader.setTextSizeTitle(13);
//            mRefreshHeader.setArrowDrawable(ContextCompat.getDrawable(getContext(), R.drawable.arrow_refresh));
//            mRefreshHeader.setEnableLastTime(false);
            mRefreshHeader = new ClassicsHeader(getContext());
            mRefreshView.setRefreshHeader(mRefreshHeader);

            mRefreshFooter = new ClassicsFooter(getContext()).setSpinnerStyle(SpinnerStyle.Scale);
            mRefreshView.setRefreshFooter(mRefreshFooter);
        }

        mActivity.getLdLoading().observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean show) {
                if (!show) {
                    onRefreshCompleted();
                    onloadMoreCompleted();
                }
            }
        });
    }

    protected boolean isRefreshing() {
        if (null == mRefreshView) {
            return false;
        }
        return (mRefreshView.getState() == RefreshState.Refreshing || mRefreshView.getState() == RefreshState.Loading);
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        onLoadMoreData();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        onRefreshData();
    }

    protected void setEnableRefresh(boolean enable) {
        if (null != mRefreshView) {
            mRefreshView.setEnableRefresh(enable);
        }
    }

    protected void setEnableLoadMore(boolean enable) {
        if (null != mRefreshView) {
            mRefreshView.setEnableLoadMore(enable);
        }
    }

    /***
     * 刷新数据完成
     */
    protected void onRefreshCompleted() {
        if (null != mRefreshView && mRefreshView.isEnableRefresh()) {
            mRefreshView.finishRefresh();
            mRefreshView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mRefreshView.setEnableRefresh(canRefresh());
                    mRefreshView.setEnableLoadMore(canLoadMore());
                }
            }, 100);
        }
    }

    /***
     * 加载数据完成
     */
    protected void onloadMoreCompleted() {
        if (null != mRefreshView && mRefreshView.isEnableLoadMore()) {
            mRefreshView.finishLoadMore();
            mRefreshView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mRefreshView.setEnableRefresh(canRefresh());
                    mRefreshView.setEnableLoadMore(canLoadMore());
                }
            }, 100);
        }
    }

    /**
     * 刷新数据
     */
    abstract protected void onRefreshData();

    /***
     * 加载更多
     */
    abstract protected void onLoadMoreData();

    /***
     * 获取刷新控件
     * @return
     */
    abstract protected SmartRefreshLayout obtainRefreshView();

    protected boolean canRefresh() {
        return true;
    }

    protected boolean canLoadMore() {
        return false;
    }

}
