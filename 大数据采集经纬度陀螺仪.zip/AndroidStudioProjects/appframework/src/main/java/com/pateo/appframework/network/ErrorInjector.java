package com.pateo.appframework.network;

import android.text.TextUtils;
import android.util.SparseArray;

import com.pateo.appframework.base.bean.ErrorDetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author huangxiaodong
 * @date 2018/7/20
 */

public class ErrorInjector {
    private static Map<String, ErrorDetail> sErrorMap = new HashMap<>(10);
    private static SparseArray<List<ErrorDetail>> sErrorSparse = new SparseArray<>(10);

    static {
        addError(ErrorDetail.ERROR_BUSY, "系统繁忙，请稍后再试");
        addError(ErrorDetail.ERROR_NO_NETWORK, "网络连接失败");
        addError(ErrorDetail.ERROR_TIMEOUT, "载入失败，请检查网络连接");
    }

    public static void addError(String errCode, String errMsg, int flag) {
        if (!TextUtils.isEmpty(errCode) && !TextUtils.isEmpty(errMsg)) {
            ErrorDetail error = new ErrorDetail(errCode, errMsg, flag);
            sErrorMap.put(errCode, error);

            List<ErrorDetail> list = sErrorSparse.get(flag);
            if (null == list) {
                list = new ArrayList<>(5);
                sErrorSparse.append(flag, list);
            }
            list.add(error);
        }
    }

    public static void addError(String errCode, String errMsg) {
        if (!TextUtils.isEmpty(errCode) && !TextUtils.isEmpty(errMsg)) {
            int flag = ErrorDetail.FLAG_DEFAULT;
            ErrorDetail error = new ErrorDetail(errCode, errMsg, flag);
            sErrorMap.put(errCode, error);

            List<ErrorDetail> list = sErrorSparse.get(flag);
            if (null == list) {
                list = new ArrayList<>(5);
                sErrorSparse.append(flag, list);
            }
            list.add(error);
        }
    }

    public static boolean containError(int flag, String errorCode) {
        List<ErrorDetail> list = sErrorSparse.get(flag);
        if (null == list || list.size() == 0) {
            return false;
        }
        for (ErrorDetail errorDetail : list) {
            if (errorDetail.errorCode.equals(errorCode)) {
                return true;
            }
        }
        return false;
    }

    public static ErrorDetail getError(String errCode, String defaultMsg) {
        if (sErrorMap.containsKey(errCode)) {
            return sErrorMap.get(errCode);
        }

        return new ErrorDetail(errCode, defaultMsg, ErrorDetail.FLAG_DEFAULT);
    }

    public static String getErrorMsg(String errCode){
        if (sErrorMap.containsKey(errCode)) {
            return sErrorMap.get(errCode).errorMsg;
        }
        return "";
    }

}
