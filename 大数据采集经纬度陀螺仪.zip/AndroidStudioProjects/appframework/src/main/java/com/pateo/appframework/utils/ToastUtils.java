package com.pateo.appframework.utils;

import android.content.Context;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import com.pateo.appframework.BuildConfig;

/**
 * ToastUtils
 *
 * @author fangxin
 * @date 2018-8-23
 */

public class ToastUtils {

    private static Toast sToast;
    private static Toast dToast;

    public static void showToast(Context context, String tip) {
        if (null == sToast) {
            sToast = Toast.makeText(context, tip, Toast.LENGTH_LONG);
        }
        sToast.setText(tip);
        sToast.show();
    }

    public static void showDebugToast(Context context, String tip) {
        if(BuildConfig.DEBUG){
            if (null == dToast) {
                dToast = Toast.makeText(context, tip, Toast.LENGTH_LONG);
                dToast.setGravity(Gravity.CENTER,0,0);
            }
            dToast.setText(tip);
            dToast.show();
        }
    }

    /**
     * 自定义背景的Toast
     *
     * @param context
     * @param text
     */
    private static TextView textView;
    private static Toast toast = null;
    public static void showCustomToast(Context context, String text) {
        showCustomToast(context, text, Toast.LENGTH_LONG);
    }

    public static void showCustomToast(Context context, String text, int duration) {
        if (context == null) {
            return;
        }
        if (toast == null || textView == null) {
            toast = Toast.makeText(context, text, duration);
            textView = new TextView(context);
            textView.setWidth(609);
            textView.setGravity(Gravity.CENTER);
            textView.setMaxLines(2);
            textView.setTextColor(context.getResources().getColor(android.R.color.white));
            textView.setTextSize(14);
//            textView.setBackgroundResource(R.drawable.toast_bg);
//            int padding = (int) context.getResources().getDimension(R.dimen.dialog_toast_text_padding);
//            int paddingBottom = (int) context.getResources().getDimension(R.dimen.dialog_progress_marginBottom_value);
//            textView.setPadding(padding * 2, padding, padding * 2, padding);
//            toast.setGravity(Gravity.BOTTOM, 0, paddingBottom);
        }
        textView.setText(text);
        toast.setView(textView);
        toast.show();
    }

    private static Toast errorMsgToast;
    public static void showErrorMsgToast(Context context, String errorMsg) {
        showToast(errorMsgToast,context,errorMsg);
    }
    private static void showToast(Toast toast,Context context,String errorMsg) {
//        if (null == toast) {
            toast = Toast.makeText(context, errorMsg, Toast.LENGTH_LONG);
//        }
        toast.setText(errorMsg);
        toast.show();
    }
}
