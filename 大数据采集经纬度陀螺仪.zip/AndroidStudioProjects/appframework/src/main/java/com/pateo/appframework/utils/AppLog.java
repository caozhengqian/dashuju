package com.pateo.appframework.utils;

import android.util.Log;

/**
 * Created by huangxiaodong on 2018/2/8.
 */

public class AppLog {
    protected static final String TAG = AppConfigure.getPackageName();

    private AppLog() {
    }

    /**
     * Send a VERBOSE log message.
     *
     * @param objects The message you would like logged.
     */
    public static void v(Object... objects) {
        if (AppConfigure.isDebugMode()) {
            Log.v(TAG, toString(objects));
        }
    }

    /**
     * Send a DEBUG log message.
     *
     * @param objects
     */
    public static void d(Object... objects) {
        if (AppConfigure.isDebugMode()) {
            Log.d(TAG, toString(objects));
        }
    }

    /**
     * Send a INFO log message.
     *
     * @param objects
     */
    public static void i(Object... objects) {
        if (AppConfigure.isDebugMode()) {
            Log.i(TAG, toString(objects));
        }
    }

    /**
     * Send a WARN log message.
     *
     * @param objects
     */
    public static void w(Object... objects) {
        if (AppConfigure.isDebugMode()) {
            Log.w(TAG, toString(objects));
        }
    }

    /**
     * Send a ERROR log message.
     *
     * @param objects
     */
    public static void e(Object... objects) {
        if (AppConfigure.isDebugMode()) {
            Log.e(TAG, toString(objects));
        }
    }

    private static String toString(Object... objects) {
        if(objects == null || objects.length == 0){
            return "nothing?_";
        }
        String tagStr = objects[0].toString();
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();

        int index = 4;
        String className = stackTrace[index].getFileName();
        String methodName = stackTrace[index].getMethodName();
        int lineNumber = stackTrace[index].getLineNumber();

        String tag = (tagStr == null ? className : tagStr);
        methodName = methodName.substring(0, 1).toUpperCase() + methodName.substring(1);

        StringBuilder sb = new StringBuilder();
        sb.append("╔═══════════════════════════════════════════════════════════════════════════════════════").append("\n");
        sb.append("[ (").append(className).append(":").append(lineNumber).append("行)#").append(methodName).append("( ) ] ")/*.append("\n")*/;
        for (Object o : objects) {
            sb.append(o);
            sb.append("  ");
        }
        sb.append("\n").append("╚════════════════════════════════════════════════════════════════════════════════════════");
        return sb.toString();
    }
}
