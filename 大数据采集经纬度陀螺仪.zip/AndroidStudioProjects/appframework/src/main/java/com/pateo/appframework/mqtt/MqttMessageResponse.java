package com.pateo.appframework.mqtt;

/**
 * Created by huangxiaodong on 2018/8/23.
 */

public class MqttMessageResponse{
    private MqttMessage message;
    private String msgId;
    private String msgVersion;
    private String sendTime;   //时间戳
    private String sessionId;


    public MqttMessage getMessage() {
        return message;
    }

    public String getMsgId() {
        return msgId;
    }

    public String getMsgVersion() {
        return msgVersion;
    }

    public String getSendTime() {
        return sendTime;
    }

    public String getSessionId() {
        return sessionId;
    }

    public class MqttMessage {
        private String businessSubtype;
        private String msgTitle;
        private String pushBody;
        private String pushBodyType;
        private String pushType;

        public String getBusinessSubtype() {
            return businessSubtype;
        }

        public void setBusinessSubtype(String businessSubtype) {
            this.businessSubtype = businessSubtype;
        }

        public String getMsgTitle() {
            return msgTitle;
        }

        public void setMsgTitle(String msgTitle) {
            this.msgTitle = msgTitle;
        }

        public String getPushBody() {
            return pushBody;
        }

        public void setPushBody(String pushBody) {
            this.pushBody = pushBody;
        }
    }
}
