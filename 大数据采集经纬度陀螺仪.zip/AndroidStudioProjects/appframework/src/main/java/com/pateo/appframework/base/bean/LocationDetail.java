package com.pateo.appframework.base.bean;

/**
 * 定位详情，由定位SDK提供，其他字段可以扩展
 * LocationDetail.java
 * Created at 2018/8/10
 * Created by huangxiaodong
 */

public class LocationDetail{
    private boolean success;
    private double latitude;
    private double longitude;
    private String city;
    private int accuracy;
    private float direction;

    public float getDirection() {
        return direction;
    }

    public void setDirection(float direction) {
        this.direction = direction;
    }

    public int getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
    }

    public LocationDetail(boolean success) {
        this.success = success;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getCoorType() {
        return coorType;
    }

    public void setCoorType(String coorType) {
        this.coorType = coorType;
    }

    private String coorType;

    public String getCity() {
        return city;
    }

    public void setCity(String cityLocation) {
        this.city = cityLocation;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "LocationData{" +
                "cityLocation='" + city + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                '}';
    }
}
