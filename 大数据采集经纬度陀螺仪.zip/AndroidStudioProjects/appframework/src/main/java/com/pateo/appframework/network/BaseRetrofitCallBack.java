package com.pateo.appframework.network;

import com.google.gson.Gson;
import com.pateo.appframework.base.bean.ErrorDetail;
import com.pateo.appframework.base.model.IModelCallback;
import com.pateo.appframework.network.monitor.NoNetworkException;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.net.ConnectException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * @author huangxiaodong
 * @date 2018/7/20
 */

public abstract class BaseRetrofitCallBack<T extends ICheckResponse> implements Callback<T> {

    private static final String TAG = BaseRetrofitCallBack.class.getSimpleName();
    private static final Gson GSON = new Gson();
    private int retryCount = 1;
    private IRefreshTokenApi refreshTokenApi;
    private IModelCallback busiCallback;

    public BaseRetrofitCallBack(IModelCallback callback, IRefreshTokenApi refreshTokenApi) {
        this.refreshTokenApi = refreshTokenApi;
        this.busiCallback = callback;
    }

    @Override
    public void onResponse(final Call<T> call, Response<T> response) {
//        AppLog.d(TAG, "onResponse=" + (response == null), GSON.toJson(response));
        T body = response.body();
//        AppLog.d(TAG, "onResponse  body=" + (body == null), response.code(), GSON.toJson(body));
        //http失败
        if (body == null) {
            if (response.code() == 200) {
                handleSuccess(call, body);
                return;
            }

            ResponseBody errorBody = response.errorBody();
            if (errorBody == null) {
                onHttpFailed(call, String.valueOf(response.code()), response.message());
                return;
            }

            try {
                String errorStr = errorBody.string();
                Type type = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
                body = GSON.fromJson(errorStr, type);
                handleError(call, body.getBusinessCode(), body.getBusinessMessage());
            } catch (Exception e) {
                onHttpFailed(call, String.valueOf(response.code()), response.message());
            }
            return;
        }

        //业务成功
        if (body.isBusinessSuccess()) {
            handleSuccess(call, body);
            return;
        }

        //业务失败
        handleError(call, body.getBusinessCode(), body.getBusinessMessage());
    }

    /**
     * Http通讯过程中发生异常，失败调用,  TransError.FATAL_ERROR99, App 定义的内部错误码
     * 此函数不需要被Override
     *
     * @param call
     * @param t
     */
    @Override
    public void onFailure(Call<T> call, Throwable t) {
        if (t instanceof ConnectException || t instanceof java.net.SocketTimeoutException) {
            ErrorDetail error = ErrorInjector.getError(ErrorDetail.ERROR_TIMEOUT, "");
            onFailed(call, error.errorCode, error.errorMsg);
        } else if (t instanceof NoNetworkException) {
            ErrorDetail error = ErrorInjector.getError(ErrorDetail.ERROR_NO_NETWORK, "");
            onFailed(call, error.errorCode, error.errorMsg);
        } else {
            ErrorDetail error = ErrorInjector.getError(ErrorDetail.ERROR_BUSY, "");
            onFailed(call, error.errorCode, error.errorMsg);
        }
    }

    /**
     * 处理Http协议状态码
     *
     * @param call
     * @param errorCode
     * @param errorMsg
     */
    protected void onHttpFailed(Call<T> call, String errorCode, String errorMsg) {
        ErrorDetail error = ErrorInjector.getError(ErrorDetail.ERROR_BUSY, "");
        onFailed(call, error.errorCode, error.errorMsg);
    }

    protected void handleSuccess(final Call<T> call, final T body) {
        onSuccess(call, body);
    }

    protected void handleError(final Call<T> call, final String busiErrorCode, final String busiErrorMsg) {
        if (null != refreshTokenApi && ErrorInjector.containError(ErrorDetail.FLAG_REFRESH_TOKEN, busiErrorCode)) {
            this.refreshTokenApi.refreshToken(new IModelCallback<Object>() {
                @Override
                public void onSuccess(Object object) {
                    if (retryCount-- > 0) {
                        Call<T> callClone = call.clone();
                        callClone.enqueue(BaseRetrofitCallBack.this);
                    } else {
                        onFailed(call, busiErrorCode, busiErrorMsg);
                    }
                }

                @Override
                public void onFailure(String errorCode, String errorMsg) {
                    BaseRetrofitCallBack.this.onTokenExpired(call, busiErrorCode, busiErrorMsg);
                }

                @Override
                public void onTokenExpired(String errorCode, String errorMsg) {
                    //do nothing
                }
            });
        } else {
            onFailed(call, busiErrorCode, busiErrorMsg);
        }
    }

    /**
     * Http通讯完成，失败调用
     *
     * @param call
     * @param errorCode
     * @param errorMsg
     */
    protected void onFailed(Call<T> call, String errorCode, String errorMsg) {
        if (null != busiCallback) {
            busiCallback.onFailure(errorCode, errorMsg);
        }
    }

    /**
     * 业务成功回调
     *
     * @param call 请求对象
     * @param body 可能为 null，子类实现中需根据需要进行非空判断
     */
    protected abstract void onSuccess(Call<T> call, T body);

    /**
     * token过期回调
     *
     * @param call
     * @param errorCode
     * @param errorMsg
     */
    protected void onTokenExpired(Call<T> call, String errorCode, String errorMsg) {
        if (null != busiCallback) {
            busiCallback.onTokenExpired(errorCode, errorMsg);
        }
    }

}
