package com.pateo.appframework.network;

import android.content.Context;
import android.text.TextUtils;

import com.pateo.appframework.utils.AppConfigure;

import java.io.File;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import okio.Buffer;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by huangxiaodong on 2018/8/8.
 */

public class HttpManager {
    private static Retrofit sRetrofit;
    private static HttpConfigParams sConfigParams;

    private HttpManager() {
    }

    public static void initialize(HttpConfigParams params){
        sConfigParams = params;
    }

    public static void setRetrofit(Retrofit retrofit){
        sRetrofit = retrofit;
    }

    public static <T> T getServiceApi(Class<T> clazz) {
        if (null == sRetrofit){
            sRetrofit = build();
        }
        return sRetrofit.create(clazz);
    }

    public static Retrofit build(){
        if (null == sConfigParams){
            sConfigParams = new HttpConfigParams();
        }

        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .connectTimeout(sConfigParams.getConnectTimeout(), TimeUnit.SECONDS)
                .readTimeout(sConfigParams.getConnectTimeout(), TimeUnit.SECONDS)
                .writeTimeout(sConfigParams.getConnectTimeout(), TimeUnit.SECONDS);

        if (!TextUtils.isEmpty(sConfigParams.getCertificate())) {
            InputStream[] streams = new InputStream[]{new Buffer().writeUtf8(sConfigParams.getCertificate()).inputStream()};
            HttpSSLVerifier.SSLParams sslParams = HttpSSLVerifier.getSslSocketFactory(streams, null, null);
            builder.sslSocketFactory(sslParams.sSLSocketFactory, sslParams.trustManager)
                    .hostnameVerifier(HttpSSLVerifier.getHostnameVerifier());
        }
        for (Interceptor interceptor : sConfigParams.getInterceptorList()){
            builder.addInterceptor(interceptor);
        }


        Context context = AppConfigure.getApplicationContext();
        if (sConfigParams.isLogEnabled() && null != context){
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            builder.addInterceptor(interceptor);
            File cacheDirectory = new File(context.getCacheDir().getAbsolutePath(), "HttpCache");
            builder.cache(new Cache(cacheDirectory, 10 * 1024 * 1024));
        }

        Retrofit.Builder rBuilder = new Retrofit.Builder()
                .client(builder.build())
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(sConfigParams.getBaseUrl());
        return rBuilder.build();
    }
    
//    public static class RetrofitBuilder {
//        public RetrofitBuilder() {
//            if (null == sConfigParams){
//                sConfigParams = new HttpConfigParams();
//            } else {
//                sConfigParams.reset();
//            }
//        }
//
//        public RetrofitBuilder addInterceptor(Interceptor interceptor){
//            if (null != interceptor) {
//                sConfigParams.interceptorList.add(interceptor);
//            }
//            return this;
//        }
//
//
//        public RetrofitBuilder setDebugUrl(String debugUrl) {
//            sConfigParams.debugUrl = debugUrl;
//            return this;
//        }
//
//        public RetrofitBuilder setReleaseUrl(String releaseUrl) {
//            sConfigParams.releaseUrl = releaseUrl;
//            return this;
//        }
//
//        public RetrofitBuilder setCertificate(String certificate) {
//            sConfigParams.certificate = certificate;
//            return this;
//        }
//
//        public RetrofitBuilder setReadtTimeout(int readtTimeout) {
//            sConfigParams.readtTimeout = readtTimeout;
//            return this;
//        }
//
//        public RetrofitBuilder setWriteTimeout(int writeTimeout) {
//            sConfigParams.writeTimeout = writeTimeout;
//            return this;
//        }
//
//        public int getConnectTimeout() {
//            return sConfigParams.connectTimeout;
//        }
//
//        public RetrofitBuilder setConnectTimeout(int timeout) {
//            sConfigParams.connectTimeout = timeout;
//            return this;
//        }
//
//        public boolean isLogEnabled() {
//            return sConfigParams.logEnabled;
//        }
//
//        public RetrofitBuilder setLogEnabled(boolean logEnabled) {
//            sConfigParams.logEnabled = logEnabled;
//            return this;
//        }
//
//        public String getBaseUrl(){
//            if (AppConfigure.isDebugMode()){
//                return sConfigParams.debugUrl;
//            }
//            return sConfigParams.releaseUrl;
//        }
//
//        public Retrofit build(){
//            OkHttpClient.Builder builder = new OkHttpClient.Builder()
//                    .connectTimeout(sConfigParams.connectTimeout, TimeUnit.SECONDS)
//                    .readTimeout(sConfigParams.connectTimeout, TimeUnit.SECONDS)
//                    .writeTimeout(sConfigParams.connectTimeout, TimeUnit.SECONDS);
//
//            if (!TextUtils.isEmpty(sConfigParams.certificate)) {
//                InputStream[] streams = new InputStream[]{new Buffer().writeUtf8(sConfigParams.certificate).inputStream()};
//                HttpSSLVerifier.SSLParams sslParams = HttpSSLVerifier.getSslSocketFactory(streams, null, null);
//                builder.sslSocketFactory(sslParams.sSLSocketFactory, sslParams.trustManager)
//                        .hostnameVerifier(HttpSSLVerifier.getHostnameVerifier());
//            }
//            for (Interceptor interceptor : sConfigParams.interceptorList){
//                builder.addInterceptor(interceptor);
//            }
//
//
//            Context context = AppConfigure.getApplicationContext();
//            if (sConfigParams.logEnabled && null != context){
//                HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
//                interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
//                builder.addInterceptor(interceptor);
//                File cacheDirectory = new File(context.getCacheDir().getAbsolutePath(), "HttpCache");
//                builder.cache(new Cache(cacheDirectory, 10 * 1024 * 1024));
//            }
//
//            Retrofit.Builder rBuilder = new Retrofit.Builder()
//                    .client(builder.build())
//                    .addConverterFactory(GsonConverterFactory.create())
//                    .baseUrl(getBaseUrl());
//            return rBuilder.build();
//        }
//    }


}
