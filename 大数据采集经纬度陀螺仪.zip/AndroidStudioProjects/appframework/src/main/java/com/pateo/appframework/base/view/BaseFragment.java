package com.pateo.appframework.base.view;

import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.pateo.appframework.base.viewmode.BaseViewModel;
import com.pateo.appframework.utils.AppConfigure;
import com.pateo.appframework.utils.AppLog;
import com.pateo.appframework.widgets.BaseToolbar;
import com.pateo.appframework.widgets.ProgressDialog;
import com.pateo.appframework.widgets.PromptDialog;


/**
 * @author huangxiaodong
 * @date 2018/7/24
 */
public abstract class BaseFragment<T extends BaseActivity, B extends ViewDataBinding,VM extends BaseViewModel> extends Fragment {
    public static final String FRAGMENT_ARGUMENTS = "fragment_arguments";
    protected VM viewModel;
//    private Observable.OnPropertyChangedCallback mLoadingCallback;
//    private Observable.OnPropertyChangedCallback mErrorCallback;
//    private Observable.OnPropertyChangedCallback mTokenCallback;

    private ProgressDialog progressDialog;
    private PromptDialog promptDialog;

    protected String TAG = this.getClass().getSimpleName();
    protected View mRootView;
    protected BaseFragment mFragment;
    protected T mActivity;
    protected B mFragmentBind;
    private BaseToolbar mToolbar;

    @Override
    public void onInflate(Context context, AttributeSet attrs, Bundle savedInstanceState) {
        super.onInflate(context, attrs, savedInstanceState);
        AppLog.d(TAG, "onInflate");
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        AppLog.d(TAG, "onAttach");
        mActivity = (T) context;
        viewModel = obtainViewModel(context);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppLog.d(TAG, "onCreate");
    }

    /**
     * 为Fragment加载布局时调用
     *
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        mFragment = this;
        AppLog.d(TAG, "onCreateView");
        mFragmentBind = DataBindingUtil.inflate(inflater, obtainLayout(), container, false);
        mRootView = mFragmentBind.getRoot();
        checkCodeFragment();
        mActivity.getmViewModel().addChildViewModel(viewModel);
        initSmartRefreshLayout();
        initView(getArguments(),savedInstanceState);
        return mRootView;
    }

    public void setViewModel(VM viewModel){
        this.viewModel = viewModel;
    }

    /**
     * 获取viewmodel
     * @return
     */
    protected abstract VM obtainViewModel(Context context);

    /**
     * 设置fragment的布局id
     *
     * @return 布局id
     */
    protected abstract int obtainLayout();

    /**
     * 初始化fragment数据
     *
     * @param arguments 来自activity的预设参数
     */
    protected abstract void initView(Bundle arguments,Bundle savedInstanceState);

    public BaseToolbar getActivityToolbar() {
        return mActivity.getToolbar();
    }

    public void setToolbar(@IdRes int xmlToolbarId) {
        this.mToolbar = mRootView.findViewById(xmlToolbarId);
        if (mToolbar != null) {
            mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mActivity.onBackPressed();
                }
            });
        }
    }

    public BaseToolbar getmToolbar() {
        return mToolbar;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        AppLog.d(TAG, "onViewCreated");
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        AppLog.d(TAG, "onActivityCreated");
//        mLoadingCallback = new Observable.OnPropertyChangedCallback() {
//            @Override
//            public void onPropertyChanged(Observable observable, int i) {
//                onShowProgress(viewModel.dataLoading.get(), "");
//            }
//        };
//
//        mErrorCallback = new Observable.OnPropertyChangedCallback() {
//            @Override
//            public void onPropertyChanged(Observable observable, int i) {
//                BaseViewModel.VMErrorMsg data = viewModel.error.get();
//                onShowErrorMsg(data.errorCode, data.errorMsg);
//            }
//        };
//
//        mTokenCallback = new Observable.OnPropertyChangedCallback() {
//            @Override
//            public void onPropertyChanged(Observable observable, int i) {
//                BaseViewModel.VMErrorMsg data = viewModel.tokenExpired.get();
//                onTokenExpired(data.errorCode, data.errorMsg);
//            }
//        };
//        if (null != viewModel &&  mActivity.vmMap.get(viewModel) == null) {
//            viewModel.dataLoading.addOnPropertyChangedCallback(mLoadingCallback);
//            viewModel.error.addOnPropertyChangedCallback(mErrorCallback);
//            viewModel.tokenExpired.addOnPropertyChangedCallback(mTokenCallback);
//            mActivity.vmMap.put(viewModel,viewModel.getClass().getSimpleName());
//        }
    }

    @Override
    public void onStart() {
        AppLog.d(TAG, "onStart super前");
        super.onStart();
        AppLog.d(TAG, "onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        AppLog.d(TAG, "onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        AppLog.d(TAG, "onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        AppLog.d(TAG, "onStop");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        AppLog.d(TAG, "onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        AppLog.d(TAG, "onDetach");
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        AppLog.d(TAG + "onHiddenChanged=", hidden);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        AppLog.d(TAG + "setUserVisibleHint=", isVisibleToUser);
    }

    private IntentArgs arguments;
    @Override
    public void setArguments(Bundle args) {
        super.setArguments(args);
        AppLog.d(TAG, "setArguments", args);
        if (args != null){
            arguments = (IntentArgs) args.getSerializable(FRAGMENT_ARGUMENTS);
        }
    }

    public BaseFragment setArguments(IntentArgs.Builder builder) {
        AppLog.d(TAG, "setMyArguments");
        if (builder != null){
            Bundle bundle = new Bundle();
            bundle.putSerializable(FRAGMENT_ARGUMENTS,builder.build());
            setArguments(bundle);
        }
        return this;
    }

    protected IntentArgs getMyArguments() {
        if(arguments == null){
            AppLog.e("没有设置默认fragment参数");
            arguments = new IntentArgs.Builder().build();
        }
        return arguments;
    }

    protected IntentArgs.Builder buildArguments() {
        return new IntentArgs.Builder();
    }

    @Override
    public void onDestroy() {
        AppLog.d(TAG, "onDestroy");
//        if (null != viewModel) {
//            viewModel.dataLoading.removeOnPropertyChangedCallback(mLoadingCallback);
//            viewModel.error.removeOnPropertyChangedCallback(mErrorCallback);
//            viewModel.tokenExpired.removeOnPropertyChangedCallback(mTokenCallback);
//        }
        super.onDestroy();
        if(mFragmentBind != null) {
            mFragmentBind.unbind();
        }
    }

    /**
     * 页面跳转
     * @param clz
     */
    public void startActivity(Class<?> clz,IntentArgs.Builder builder){
        Intent intent = new Intent();
        intent.setClass(mActivity, clz);
        Bundle bundle = new Bundle();
        bundle.putSerializable("intentArgs",builder.build());
        intent.putExtra("DefArgs_bundle",bundle);
        startActivity(intent);
    }

    /**
     * [页面跳转] * * @param clz
     */
    public void startActivity(Class<?> clz) {
        Intent intent = new Intent();
        intent.setClass(mActivity, clz);
        startActivity(intent);
    }

    /**
     * [携带数据的页面跳转] * * @param clz * @param bundle
     */
    public void startActivity(Class<?> clz, Bundle bundle) {
        Intent intent = new Intent();
        intent.setClass(mActivity, clz);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }


//    protected void onShowProgress(boolean show, String progressMsg) {
//        if (null == progressDialog) {
//            progressDialog = ProgressDialog.newInstance(progressMsg);
//        }
//        if (show) {
//            AppCompatActivity activity = AppActivityManager.getInstance().currentActivity();
//            if (null != activity) {
//                progressDialog.setMessage(progressMsg)
//                        .show(activity.getSupportFragmentManager(), null);
//            }
//        } else {
//            progressDialog.dismissAllowingStateLoss();
//        }
//    }
//
//    protected void onShowErrorMsg(String errorCode, String errorMsg) {
//        if (null == promptDialog) {
//            promptDialog = PromptDialog.newInstance(errorMsg);
//        }
//        if (promptDialog.isAdded()) {
//            return;
//        }
//        promptDialog.setMessage(errorMsg);
//        AppCompatActivity activity = AppActivityManager.getInstance().currentActivity();
//        if (null != activity) {
//            promptDialog.show(activity.getSupportFragmentManager(), null);
//        }
//    }

    protected void onTokenExpired(String errorCode, String errorMsg) {

    }

    private void checkCodeFragment() {
        if(AppConfigure.IS_CHECK_WARN){
            if(mFragmentBind == null){
                AppLog.e(TAG,"必须使用DataBindingUtil.inflate()方法");
                if(AppConfigure.IS_CHECK_CONSTRAINT){
                    throw new NullPointerException(TAG+"必须使用DataBindingUtil.inflate()方法");
                }
            }else{
                String s = mFragmentBind.getClass().getSimpleName().replace("Fragment","").replace("Binding","");
                if(!TAG.replace("Fragment","").equals(s)){
                    AppLog.e(TAG,"layout命名不规范");
                    if(AppConfigure.IS_CHECK_CONSTRAINT){
                        throw new NullPointerException(TAG+"layout命名不规范");
                    }
                }
            }
        }
    }

    protected void initSmartRefreshLayout() {

    }
}
