package com.pateo.appframework.common.adapter.recycle;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.List;

/**
 * RecyclerView通用适配器
 *
 * @author fangxin
 * @date 2018-8-23
 */
public abstract class ComRecycleAdapter<T> extends RecyclerView.Adapter<RecyclerViewHolder> {
    private Context mContext;
    private int mLayoutId;
    private List<T> data;
    private IItemRecycleListener itemRcvListener;

    public ComRecycleAdapter(Context context, int layoutId, IItemRecycleListener itemRcvListener) {
        this(context, layoutId, null, itemRcvListener);
    }

    public ComRecycleAdapter(Context context, int layoutId, List<T> data, IItemRecycleListener itemRcvListener) {
        mContext = context;
        mLayoutId = layoutId;
        this.data = data;
        this.itemRcvListener = itemRcvListener;
    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        RecyclerViewHolder viewHolder = RecyclerViewHolder.get(mContext, parent, mLayoutId, itemRcvListener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        convert(holder, (T) data.get(position));
    }

    /**
     * 需要自己实现的方法，这个方法，用来处理条目的显示效果
     *
     * @param holder 里面有布局文件的控件
     * @param t      每个条目对应的数据对象
     */
    public abstract void convert(RecyclerViewHolder holder, T t);

    @Override
    public int getItemCount() {
        return data != null ? data.size() : 0;
    }

    public void setData(List<T> data) {
        this.data = data;
        notifyDataSetChanged();
    }
}