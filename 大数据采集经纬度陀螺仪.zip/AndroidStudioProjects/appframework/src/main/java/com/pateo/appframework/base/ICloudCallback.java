package com.pateo.appframework.base;

import android.content.Context;
import android.os.Bundle;

/**
 * 1.当接收到push消息时，会调用此接口传输
 * 2.建议继承此接口的类做成单例，作为viewModle设置给消息列表和通知界面
 * 3.此接口和业务无关
 * Created by huangxiaodong on 2018/8/13.
 */

public interface ICloudCallback {
    void onRegistered(Context context, String registrationId);

    void onRecvMessage(Context context, String msgId, String title, String message, String extra);

    void onNotificationOpened(Context context, String msgId, String title, String content, String extra);

    void onConnectionChange(Context context, boolean connected);
}